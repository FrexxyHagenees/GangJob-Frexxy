function GetLimitData(categoryOrWeapon)
    return Limits[categoryOrWeapon] or Weapons[categoryOrWeapon]
end

function GetPrice(category, price, numBought)
    local limitData = GetLimitData(category)
    local modifier = 1
    local divider = 3
    local exponent = 2
    if limitData then
        modifier = limitData.modifier or 1
        divider = limitData.divider or 3
        exponent = limitData.exponent or 2
    end
    local multiplier = math.max(numBought - modifier, 0)
    price = price + math.floor((price / divider) * multiplier ^ exponent)
    price = math.floor((price + 2500) / 5000) * 5000
    return price
end

function GetNumBought(data, category)
    return data[category]
end