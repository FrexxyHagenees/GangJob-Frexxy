fx_version 'adamant'
game 'gta5'
use_fxv2_oal 'true'

description 'ESX Biker Job'

version '1.0.1'

shared_scripts {
	'shared.lua'
}

client_scripts {
	'@esx_boilerplate/natives.lua',
	'@es_extended/locale.lua',
	'@esx_boilerplate/utils/logger.lua',
	'@esx_boilerplate/utils/threads.lua',
	'@esx_boilerplate/utils/lazy_esx.lua',
	'locales/en.lua',
	'config.lua',
	'client/Menus.lua',
	'client/main.lua',
	'client/takehostage_client.lua',
}

server_scripts {
	'@esx_boilerplate/natives_server.lua',
	'@anticheat/event_s.lua',
	'@es_extended/locale.lua',
	'@esx_boilerplate/task_queue.lua',
	'@esx_boilerplate/utils/logger.lua',
	'@esx_boilerplate/utils/lazy_esx.lua',
	'@esx_datastore/lib/datastore.lua',
	'locales/en.lua',
	'@mysql-async/lib/MySQL.lua',
	'config.lua',
	'server/takehostage_server.lua',
	'server/main.lua'
}