Events = Events or {}
PlayerData = {}
Stations = {}
local cuffedPeds = {}
CurrentAction, CurrentActionMsg, CurrentActionData = nil, '', {}

local hasAlreadyEnteredMarker = false
local lastStation, lastPart, lastPartNum = nil, nil, nil
local handcuffTimer = {}
local LastEntity                = nil
local isHandcuffed, isDragged = false, false
local copPed                    = 0
local blips                     = {}
local keyRunning                = false
local drawDistance              = Config.DrawDistance
local playerGender = nil
local min = math.min
JobName = nil
JobData = {}

DecorRegister("_IS_HANDCUFFED", 2)

Citizen.CreateThread(function()
    while not ESX do
        TriggerEvent('esx:getSharedObject', function(obj) ESX = obj end)
        Citizen.Wait(500)
    end
    
    while not ESX.IsPlayerLoaded() do
        Citizen.Wait(500)
    end

    PlayerData = ESX.GetPlayerData()
    RefreshJob()

    TriggerEvent('skinchanger:getSkin', function(skin)
        playerGender = skin.sex
    end)

    xpcall(function()
		local isHandcuffed = GetResourceKvpString(("%s_IsHandcuffed"):format(GetCurrentServerEndpoint()))
		if isHandcuffed then
			isHandcuffed = json.decode(isHandcuffed)
			if isHandcuffed then
				SetHandcuffed(isHandcuffed)
                StartHandcuffTimer()
			end
		end
	end, Traceback)
end)

exports('getCrimeJobs', function()
    local result = {}
    for k,v in pairs(Config.Jobs) do
        if v.criminal then
            result[k] = true
        end
    end
    return result
end)

local function isPlayerWhitelisted()
    if Config.Stations[JobName] ~= nil then
        return true
    else
        return false
    end
end

function GetCrimeJobs()
    local jobs = {}
    for k,v in pairs(Config.Jobs) do
        jobs[k] = true
    end

    return jobs
end

exports("getCrimeJobs", GetCrimeJobs)

function IsCrimeJob(job)
    job = job or JobName
    if Config.Jobs[job] and Config.Jobs[job].criminal then
        return true
    else
        return false
    end
end

AddEventHandler("isHandcuffed", function(cb)
	if not cb then
		return
	end

	if isHandcuffed then
		cb(isHandcuffed)
	end
end)

exports("isCrimeJob", IsCrimeJob)

local function SetVehicleMaxMods(vehicle)
    local props = {
        modEngine       = 2,
        modBrakes       = 2,
        modTransmission = 2,
        modSuspension   = 3,
        modTurbo        = true,
    }

    ESX.Game.SetVehicleProperties(vehicle, props)
end

local pushingAnimDict = "switch@trevor@escorted_out"
local pushingAnim = "001215_02_trvs_12_escorted_out_idle_guard2"
local isDragging, targetId = false, nil
local running = false
function StartDragging(serverPlayer)
    TriggerServerEvent('esx_crimejob:drag', serverPlayer)

    isDragging = true
	targetId = serverPlayer
	if running then
		return
	end

	running = true
	Citizen.CreateThread(function()
		while isDragging do
			Citizen.Wait(0)
			DisableControlAction(2, 21, true)
			local playerPed = PlayerPedId()
			local targetPed = GetPlayerPed(GetPlayerFromServerId(targetId))
			if not IsEntityAttachedToEntity(targetPed, playerPed) then
				Citizen.Wait(500)
				if not IsEntityAttachedToEntity(targetPed, playerPed) then
					isDragging = false
                    StopAnimTask(playerPed, pushingAnimDict, pushingAnim, -4.0)
                    break
				end
			end
			local isWalking = IsPedWalking(playerPed)
			local isPlayingAnim = IsEntityPlayingAnim(playerPed, pushingAnimDict, pushingAnim, 3)
			if isWalking and not isPlayingAnim then
				LoadDict(pushingAnimDict)
				TaskPlayAnim(playerPed, pushingAnimDict, pushingAnim, 2.0, 2.0, -1, 51, 0, false, false, false)
			elseif not isWalking and isPlayingAnim then
				StopAnimTask(playerPed, pushingAnimDict, pushingAnim, -4.0)
			end
		end
		running = false
	end)
end

local walkingAnimDict = "anim@move_m@grooving@"
local walkingAnim = "walk"
function SetIsDragged(value)
	if not value and isDragged then
		ReleasePed()
	end

	isDragged = value
end

AddEventHandler('skinchanger:loadSkin', function(character)
    playerGender = character.sex
end)

local bonesToCheck = {
	0x9995
}
--- Does a raycast to check if there's anything between the two peds
local function canReachPed(playerPed, ped)
	if not HasEntityClearLosToEntity(ped, playerPed, 17) then
		return false
	end

	for i=1, #bonesToCheck do
		local boneCoords = GetPedBoneCoords(ped, bonesToCheck[i])
		local boneCoords2 = GetPedBoneCoords(ped, bonesToCheck[i])
		local rayHandle = StartShapeTestLosProbe(boneCoords, boneCoords2, 19)
		local finished, hit, _, _, _ = GetShapeTestResult(rayHandle)
		while finished ~= 0 and finished ~= 2 do
			Citizen.Wait(0)
			finished, hit, _, _, _ = GetShapeTestResult(rayHandle)
		end
	
		if hit == 0 then
			return true
		end
	end

	return false
end

function SelectPlayer()
    local p = promise.new()
    local playerPed = PlayerPedId()
    local playersNearby = ESX.Game.GetVisiblePlayersInArea(GetEntityCoords(playerPed), 3.0)

    local elements = {}

    local playerId = PlayerId()
    for k,player in ipairs(playersNearby) do
        if player ~= playerId and canReachPed(playerPed, GetPlayerPed(player)) then
            local serverId = GetPlayerServerId(player)
            table.insert(elements, {
                label = serverId,
                playerId = serverId
            })
        end
    end

    if #playersNearby > 0 and #elements > 0 then

        ESX.UI.Menu.Open('default', GetCurrentResourceName(), 'player_selection', {
            title    = "Voer actie uit op...",
            align    = 'top-right',
            elements = elements
        }, function(playerSelectData, playerSelectMenu)
            local selectedPlayer, serverPlayer = GetPlayerFromServerId(playerSelectData.current.playerId), playerSelectData.current.playerId
            if serverPlayer == -1 then
                p:resolve({})
            end
            
            if #(GetEntityCoords(GetPlayerPed(selectedPlayer)) - GetEntityCoords(playerPed)) < 5.0 then
                playerSelectMenu.close()
                p:resolve({selectedPlayer, serverPlayer})
            end
        end, function(data2, menu2)
            menu2.close()
            p:resolve({})
        end)
    else
        ESX.ShowNotification(_U('no_players_nearby'))
        p:resolve({})
    end
    return table.unpack(Citizen.Await(p))
end

local lightbars
local function GetLightbarModels()
    if not lightbars then
        pcall(function()
            lightbars = exports['test_lightbarScript']:GetLightbarModels()
        end)
    end

    return lightbars
end

function OpenBikerActionsMenu()
    ESX.UI.Menu.CloseAll()

    ESX.UI.Menu.Open(
    'default', GetCurrentResourceName(), 'biker_actions',
    {
        title    = JobName,
        align    = 'top-right',
        elements = {
            {label = _U('citizen_interaction'), value = 'citizen_interaction'},
            --{label = _U('vehicle_interaction'), value = 'vehicle_interaction'},
        },
    },
    function(data, menu)
        if data.current.value == 'citizen_interaction' then
            local playerPed = PlayerPedId()

            local selectedPlayer, serverPlayer = SelectPlayer()

            if not selectedPlayer or not serverPlayer then
                return
            end

            local elements = {}


            if Config.Jobs[JobName].criminal then
                table.insert(elements, {label = _U('uncuff'),value = 'uncuff'})
                table.insert(elements, {label = _U('handcuff'),		value = 'handcuff'})
                table.insert(elements, {label = _U('drag'),      value = 'drag'})
                table.insert(elements, {label = _U('put_in_vehicle'),  value = 'put_in_vehicle'})
                table.insert(elements, {label = _U('out_the_vehicle'), value = 'out_the_vehicle'})
                table.insert(elements, {label = _U('id_card'),		value = 'identity_card'})
                table.insert(elements, {label = _U('search'), value = 'body_search'})
            end

            if JobName == 'justitie' and CanMangageLicense() then
                table.insert(elements, {label = 'Vergunningen beheren',value = 'permits'})
            end
    

            ESX.UI.Menu.Open(
            'default', GetCurrentResourceName(), 'citizen_interaction',
            {
                title    = _U('citizen_interaction'),
                align    = 'top-right',
                elements = elements
                
            },
            function(data2, menu2)
                if #(GetEntityCoords(GetPlayerPed(selectedPlayer)) - GetEntityCoords(playerPed)) < 5.0 then
                    local action = data2.current.value
                    if action == 'handcuff' then
                        if not IsStandingBehindPlayer(selectedPlayer) then
                            ESX.ShowNotification("~r~Je kunt alleen iemand van achter boeien!~s~")
                            return
                        end
                        TriggerServerCallback('esx_crimejob:canHandcuff', function(canHandcuff)
                            if canHandcuff then
                                TriggerServerEvent('esx_ruski_areszt:startAreszt', serverPlayer)									-- Rozpoczyna Funkcje na Animacje (Cala Funkcja jest Powyzej^^^)
                                Citizen.Wait(1790)																									-- Czeka 2.1 Sekund**
                                Citizen.Wait(1500)																									-- Czeka 3.1 Sekund**
                                TriggerServerEvent('esx_crimejob:handcuff',  serverPlayer, true, `esx_crimejob:handcuff`)
                            else
                                ESX.ShowNotification("Je hebt ~r~geen handboeien~s~ bij je")
                            end
                        end, serverPlayer)
                        
                    elseif action == 'uncuff' then
                        if not IsStandingBehindPlayer(selectedPlayer) then
                            ESX.ShowNotification("~r~Je kunt alleen iemand van achter boeien!~s~")
                            return
                        end
                        local target, distance = ESX.Game.GetClosestPlayer()
                        local playerheading = GetEntityHeading(PlayerPedId())
                        local playerVector = GetEntityForwardVector(PlayerPedId())
                        local playerCoords = GetEntityCoords(PlayerPedId())
                        local target_id = GetPlayerServerId(target)
                        TriggerServerEvent('esx_policejob:requestrelease', target_id, playerheading, playerCoords, playerVector)
                        TriggerServerEvent('esx_crimejob:handcuff', serverPlayer, false, `esx_crimejob:handcuff`)
                    elseif action == 'drag' then
                        if not IsStandingBehindPlayer(selectedPlayer) then
                            ESX.ShowNotification("~r~Je kunt alleen iemand van achter escorteren!~s~")
                            return
                        end
                        StartDragging(serverPlayer)
                    elseif data2.current.value == 'put_in_vehicle' then
                        TriggerServerEvent('esx_crimejob:putInVehicle', serverPlayer)
                    elseif data2.current.value == 'out_the_vehicle' then
                        TriggerServerEvent('esx_crimejob:OutVehicle', serverPlayer)
                    elseif data2.current.value == 'body_search' then
                        TriggerServerEvent('esx_crimejob:message', serverPlayer or false, _U('being_searched', GetPlayerServerId(PlayerId())), `esx_crimejob:message`)
                        OpenBodySearchMenu(selectedPlayer)
                    elseif action == "identity_card" then
                        TriggerServerEvent('jsfour-idcard:open', serverPlayer, GetPlayerServerId(PlayerId()), false, true)
					    menu2.close()
                    elseif data2.current.value == 'permits' then
                        OpenGamblePermitActionsMenu(selectedPlayer)
                    end
                    
                else
                    ESX.ShowNotification("Speler is niet meer dichtbij")
                end
            end,
            function(data2, menu2)
                menu2.close()
            end)
        elseif data.current.value == 'vehicle_interaction' then
            ESX.UI.Menu.Open(
            'default', GetCurrentResourceName(), 'vehicle_interaction',
            {
                title    = _U('vehicle_interaction'),
                align    = 'top-right',
                elements = {
                    {label = _U('pick_lock'),    value = 'hijack_vehicle'},
                },
            },
            function(data2, menu2)
                local playerPed = PlayerPedId()
                local coords    = GetEntityCoords(playerPed)
                local vehicle, distance = ESX.Game.GetClosestVehicle(coords, GetLightbarModels())
                if distance > 3.0 or distance == -1 then
                    vehicle = nil
                end

                if vehicle and DoesEntityExist(vehicle) then
                    local vehicleData = ESX.Game.GetVehicleProperties(vehicle)

                    if data2.current.value == 'hijack_vehicle' then
                        local playerPed = PlayerPedId()
                        local coords    = GetEntityCoords(playerPed)

                        if IsAnyVehicleNearPoint(coords.x, coords.y, coords.z, 3.0) then
                            local vehicle, distance = ESX.Game.GetClosestVehicle(coords, GetLightbarModels())

                            if distance > 3.0 or distance == -1 then
                                vehicle = nil
                            end

                            if vehicle and DoesEntityExist(vehicle) then
                                NetworkRequestControlOfEntity(vehicle)

                                Citizen.CreateThread(function()
                                    local counter = 0
                                    while not NetworkHasControlOfEntity(vehicle) and counter < 50 do
                                        counter = counter + 1
                                        NetworkRequestControlOfEntity(vehicle)
                                        Citizen.Wait(100)
                                    end
                                end)
                                Citizen.Wait(300)
                                Citizen.CreateThread(function()
                                    local vehicleModel = GetDisplayNameFromVehicleModel(GetEntityModel(vehicle))
                                    local vehicleLabel = GetLabelText(vehicleModel)
                                    local streetName,_ = GetStreetNameAtCoord(coords.x, coords.y, coords.z)
                                    local streetName = GetStreetNameFromHashKey(streetName)
                                    TriggerServerEvent('esx_outlawalert:carJackInProgress', {
                                        x = ESX.Math.Round(coords.x, 1),
                                        y = ESX.Math.Round(coords.y, 1),
                                        z = ESX.Math.Round(coords.z, 1)
                                    }, streetName, vehicleLabel, playerGender)

                                    TaskStartScenarioInPlace(playerPed, "WORLD_HUMAN_WELDING", 0, true)
                                    SetVehicleAlarmTimeLeft(vehicle, 120000)
                                    StartVehicleAlarm(vehicle)

                                    Citizen.Wait(60000)

                                    if IsPedUsingScenario(playerPed, "WORLD_HUMAN_WELDING") then
                                        ClearPedTasks(playerPed)

                                        if DoesEntityExist(vehicle) and not IsEntityDead(vehicle) then
                                            SetVehicleDoorsLocked(vehicle, 1)
                                            SetVehicleDoorsLockedForAllPlayers(vehicle, false)
                                            SetVehicleNeedsToBeHotwired(vehicle, true)
                                            TriggerEvent("nocarjack:addVehicle", NetworkGetNetworkIdFromEntity(vehicle))

                                            TriggerEvent('esx:showNotification', _U('vehicle_unlocked'))
                                        end
                                    end
                                end)
                            end
                        end
                    end
                else
                    ESX.ShowNotification(_U('no_vehicles_nearby'))
                end
            end,
            function(data2, menu2)
                menu2.close()
            end)
        end
    end,
    function(data, menu)
        menu.close()
    end)
end

function OpenGamblePermitActionsMenu(player)
	local elements = {
		{label = 'Check vergunning', value = 'check_license'},
		{label = 'Geef vergunning', value = 'activate_license'},
		{label = 'Ontneem Vergunning', value = 'deactivate_license'}
	}

	ESX.UI.Menu.Open('default', GetCurrentResourceName(), 'license_actions', {
		title    = 'Vergunning mangament',
		align    = 'top-right',
		elements = elements
	}, function(data, menu)
			local coords = GetEntityCoords(PlayerPedId())
			local distance = #(GetEntityCoords(GetPlayerPed(player)) - coords)
			if player == -1 or distance > 1.0 then
				ESX.ShowNotification(_U('no_players'))
			else
				if data.current.value == 'check_license' then
					TriggerServerCallback('esx_license:checkLicense', function(hasDriversLicense)
						if hasDriversLicense then
							ESX.ShowNotification(('%s heeft een Gokvergunning'):format(GetPlayerName(player)))
						else
							ESX.ShowNotification(('%s heeft geen Gokvergunning'):format(GetPlayerName(player)))
						end
					end, GetPlayerServerId(player), 'gamble')
				elseif data.current.value == 'deactivate_license' then
					ESX.ShowNotification(('Je hebt de Gokvergunning van %s gedeactiveerd'):format(GetPlayerName(player)))
                    TriggerServerEvent('esx_bikerjob:removeLicense', GetPlayerServerId(player))
                    
				elseif data.current.value == 'activate_license' then
					ESX.ShowNotification(('Je hebt de Gokvergunning van %s geactiveerd'):format(GetPlayerName(player)))
                    TriggerServerEvent('esx_bikerjob:addLicense', GetPlayerServerId(player))
				end
			end
	end, function(data, menu)
		menu.close()
	end)
end



function GetOtherPlayerData(target)
    return ServerCallback('esx_crimejob:getOtherPlayerData', target)
end

function IsWithinRange(target, range)
    local targetCoords = NetworkGetPlayerCoords(target)
    local coords = GetEntityCoords(PlayerPedId())
    return #(targetCoords - coords) < range
end

function OpenBodySearchMenu(player, playerData)
    local serverId = GetPlayerServerId(player)
    playerData = playerData or GetOtherPlayerData(serverId)
    local elements = {}

    local blackMoney = 0
    for i=1, #playerData.accounts, 1 do
        if playerData.accounts[i].name == 'black_money' then
            blackMoney = playerData.accounts[i].money
        elseif playerData.accounts[i].name == 'money' then
            blackMoney = blackMoney + playerData.accounts[i].money
        end
    end

    if playerData.money then
        blackMoney = blackMoney + playerData.money
    end

    table.insert(elements, {
        label          = _U('confiscate_dirty') .. blackMoney,
        value          = 'black_money',
        itemType       = 'item_account',
        amount         = blackMoney
    })

    table.insert(elements, {
        label = '--- Wapens ---',
        value = nil
    })

    for i=1, #playerData.weapons, 1 do
        table.insert(elements, {
            label          = _U('confiscate') .. ESX.GetWeaponLabel(playerData.weapons[i].name),
            value          = playerData.weapons[i].name,
            itemType       = 'item_weapon',
            amount         = playerData.weapons[i].ammo,
        })
    end

    table.insert(elements, {
        label = _U('inventory_label'),
        value = nil
    })

    for k,v in pairs(playerData.inventory) do
        if v.count > 0 then
            table.insert(elements, {
                label          = _U('confiscate_inv') .. v.count .. ' ' .. v.label,
                value          = v.name,
                itemType       = 'item_standard',
                amount         = v.count,
            })
        end
    end

    ESX.UI.Menu.Open(
    'default', GetCurrentResourceName(), 'body_search',
    {
        title    = _U('search'),
        align    = 'top-right',
        elements = elements,
    },
    function(searchData, searchMenu)
        if isPlayerWhitelisted() and Config.Stations[JobName][1].CanConfiscate then
            Citizen.Wait(1000)
            if not IsWithinRange(player, 3.0) then
                ESX.ShowNotification("Speler is te ver weg!")
                searchMenu.close()
                return
            end
            local itemType = searchData.current.itemType
            local itemName = searchData.current.value
            local serverPlayer = serverId

            ESX.UI.Menu.Open('dialog', GetCurrentResourceName(), 'inventory_item_count_give', {
                title = 'Aantal' .. (searchData.current.amount and (" (Max %s)"):format(searchData.current.amount) or "")
            }, function(countData, countMenu)
                local quantity = tonumber(countData.value)
            
                    if quantity then
                        
                        if IsPlayerDead(player) then
                            TriggerEvent('esx:showNotification', 'Je kan niet conficeren van een speler die dood is')
                            return
                        end
                    
                        if searchData.current.value ~= nil then
                            TriggerServerEvent('esx_bikerjob:confiscatePlayerItem', serverPlayer, itemType, itemName, quantity, `esx_policejob:confiscatePlayerItem`)
                            OpenBodySearchMenu(player)
                        end
                        
                        countMenu.close()
                    else
                        ESX.ShowNotification(_U('amount_invalid'))
                    end
            end, function(data3, menu3)
                menu3.close()
            end)
        else
            TriggerEvent('esx:showNotification', 'Je kan niet confisceren')
        end
    end,
    function(data, menu)
        menu.close()
    end)
end

if DevServer then

    RegisterCommand("test_search", function(source, args, raw)
        TriggerServerCallback("esx_crimejob:requestPlayerData", function(data)
            OpenBodySearchMenu(PlayerId(), data)
        end, GetPlayerServerId(PlayerId()))
    end)

    RegisterCommand("test_cuff", function(source, args, raw)
        TriggerServerCallback("esx_bikerjob:requestCuff", function(canCuff)
            --TriggerServerEvent("")
            SetHandcuffed(true)
            -- code to cuff target player
            -- if canCuff then
            --     TriggerServerEvent('esx_ruski_areszt:startAreszt', GetPlayerServerId(PlayerId()))
            --     Citizen.Wait(1790)
            --     TriggerServerEvent('InteractSound_SV:PlayWithinDistance', 2.0, 'cuffeffect', 0.9)
            --     Citizen.Wait(1500)
            --     TriggerServerEvent('esx_crimejob:handcuff',  GetPlayerServerId(PlayerId()), true, `esx_crimejob:handcuff`)
            --     cuffedPeds[GetPlayerServerId(PlayerId())] = true
            --     --StartPlayerHandcuffThread()
            -- end
            print("runned test cuff servercallback")
        end, GetPlayerServerId(PlayerId()))
    end, false)
end

function RequestCuff(source, args, raw)
    if IsRateLimited("request_cuff", 10) then
        ESX.ShowNotification("Wacht even voordat je iemand opnieuw probeert te boeien")
        return
    end

    local hasItem = ESX.HasInventoryItem("handcuff")
    if not hasItem then
        ESX.ShowNotification("Je hebt geen handboeien en kunt deze actie niet verrichten")
        return
    end

    local selectedPlayer, serverPlayer = SelectPlayer()
    if not selectedPlayer or not serverPlayer then
        return
    end

    TriggerServerCallback("esx_bikerjob:requestCuff", function(canCuff)
        if canCuff then
            TriggerServerEvent('esx_ruski_areszt:startAreszt', serverPlayer)
            Citizen.Wait(1790)
            TriggerServerEvent('InteractSound_SV:PlayWithinDistance', 2.0, 'cuffeffect', 0.9)
            Citizen.Wait(1500)
            TriggerServerEvent('esx_crimejob:handcuff',  serverPlayer, true, `esx_crimejob:handcuff`)
            cuffedPeds[serverPlayer] = true
            StartPlayerHandcuffThread()
        end
    end, serverPlayer)
end

RegisterNetEvent('wd:oPD', function(source)
    if cuffedPeds[source] then
        cuffedPeds[source] = nil
    end
end)

local isCuffThreadRunning = false

function StartPlayerHandcuffThread()
    if isCuffThreadRunning then
        return
    end
    isCuffThreadRunning = true
    Citizen.CreateThread(function()
        local shouldShowNotification = false
        local count = 0
        while isCuffThreadRunning do
            local playerPed = PlayerPedId()
            local playerCoords = GetEntityCoords(playerPed)
            local hasPlayerInTable = false
            for k,v in pairs(cuffedPeds) do
                hasPlayerInTable = true
                local player = GetPlayerFromServerId(k)
                if player and player ~= -1 then
                    local entity = GetPlayerPed(player)
                    local distance = #(playerCoords - GetEntityCoords(entity))
                    count = count + 1
                    if count > 20 then
                        if DoesEntityExist(entity) then
                            if IsEntityHandcuffed(entity, k) then
                                if distance < 1.5 then
                                    shouldShowNotification = true
                                else
                                    Citizen.Wait(distance * 10)
                                    shouldShowNotification = false
                                end
                            else
                                cuffedPeds[k] = nil
                            end
                        end
                        count = 0
                    end
                    if shouldShowNotification then
                        local targetCoords = GetEntityCoords(entity) + vector3(0, 0, 0.9)
                        ESX.ShowFloatingHelpNotification("Houd    ~INPUT_CONTEXT~ingedrukt om te ontboeien", targetCoords)
                        if HoldKey(38) then
                            local playerheading = GetEntityHeading(PlayerPedId())
							local playerVector = GetEntityForwardVector(PlayerPedId())
							local playerCoords = GetEntityCoords(PlayerPedId())
                            TriggerServerEvent('esx_policejob:requestrelease', k, playerheading, playerCoords, playerVector)
                            TriggerServerEvent('esx_crimejob:handcuff',  k, false, `esx_crimejob:handcuff`)
                            cuffedPeds[k] = nil
                        end
                    end
                end
            end
            if not hasPlayerInTable then
                break
            end
            Citizen.Wait(0)
        end
        isCuffThreadRunning = false
    end)
end

function HoldKey(key, time)
    time = time or 2000
    local start = GetGameTimer()
    while IsControlPressed(0, key) and GetGameTimer() - start < time do
        Citizen.Wait(0)
    end
    if GetGameTimer() - start < time then
        return false
    end
    return true
end

if DevServer then
    RegisterCommand("uncuff_self", function (src, args, raw)
        SetHandcuffed(false)
    end, false)
end

local isCuffRequest = false
local runningCuff = false
function SetRequestCuff(value, target)
    isCuffRequest = value

    if not isCuffRequest or runningCuff then
        return
    end
    runningCuff = true
    Citizen.CreateThread(function()
        while isCuffRequest do
            if IsDisabledControlJustReleased(0, 246) then
                local distance = 0
                local target = GetPlayerFromServerId(target)
                if target == -1 then
                    SetRequestCuff(false)
                    break
                end
                distance = #(GetEntityCoords(PlayerPedId()) - GetEntityCoords(GetPlayerPed(target)))
                if distance ~= -1 and distance < 5 then
                    ESX.ShowNotification("Verzoek op boeien geaccepteerd")
                    TriggerServerEvent("esx_bikerjob:acceptCuffRequest")
                    SetRequestCuff(false)
                    break
                else
                    ESX.ShowNotification("Speler is niet meer dichtbij!")
                    TriggerServerEvent("esx_bikerjob:refuseCuffRequest")
                    SetRequestCuff(false)
                    break
                end
            elseif IsDisabledControlJustReleased(0, 182) then
                ESX.ShowNotification("Verzoek op boeien  afgewezen!")
                TriggerServerEvent("esx_bikerjob:refuseCuffRequest")
                SetRequestCuff(false)
                break
            end 
            Citizen.Wait(0)
        end
        runningCuff = false
    end)
end

RegisterNetEvent("esx_bikerjob:startRequestCuffThread", function(source)
    local target = GetPlayerServerId(PlayerId())
    exports['esx_rpchat']:PrintToChat("Boeien", ("%s wil je boeien, druk op ^3^*Y^0^r om dit te accepteren of op ^*^5L^0^r om dit af te wijzen!"):format(source), { r = 255, important = true })
    SetRequestCuff(true, target)
end)

RegisterCommand("request_cuff", RequestCuff)

function IsEntityHandcuffed(entity, serverPlayer)
	local decor = "_IS_HANDCUFFED"
	if DecorExistOn(entity, decor) and DecorGetBool(entity, decor) then
		return true
	end

	if Player(serverPlayer).state.IsHandcuffed then
		return true
	end

	return false
end

function RequestSearch(source, args, raw)
    if IsRateLimited("request_search", 10) then
        ESX.ShowNotification("Wacht even voordat je opnieuw iemand probeert te fouilleren!")
        return
    end

    local selectedPlayer, serverPlayer = SelectPlayer()

    if not selectedPlayer or not serverPlayer then
        return
    end

    TriggerServerCallback("esx_crimejob:requestPlayerData", function(data)
        OpenBodySearchMenu(selectedPlayer, data)
    end, serverPlayer)
end

RegisterCommand("request_search", RequestSearch)
RegisterCommand("fouilleren", RequestSearch)
RegisterCommand("rs", RequestSearch)

function SimpleNotify(message)
    SetNotificationTextEntry("STRING")
    AddTextComponentString(message)
    DrawNotification(0,1)
end

local isRequest = false
local running = false
function SetRequestSearch(value, target)
    isRequest = value

    if not isRequest or running then
        return
    end
    running = true
    Citizen.CreateThread(function()
        while isRequest do
            if IsDisabledControlJustReleased(0, 246) then
                local distance = 0
                local target = GetPlayerFromServerId(target)
                if target == -1 then
                    SetRequestSearch(false)
                    break
                end
                distance = #(GetEntityCoords(PlayerPedId()) - GetEntityCoords(GetPlayerPed(target)))
                if distance ~= -1 and distance < 5 then
                    ESX.ShowNotification("Verzoek op fouilleren geaccepteerd")
                    TriggerServerEvent("esx_crimejob:acceptRequest")
                    SetRequestSearch(false)
                    break
                else
                    ESX.ShowNotification("Speler is niet meer dichtbij!")
                    TriggerServerEvent("esx_crimejob:refuseRequest")
                    SetRequestSearch(false)
                    break
                end
            elseif IsDisabledControlJustReleased(0, 182) then
                ESX.ShowNotification("Verzoek op fouilleren afgewezen!")
                TriggerServerEvent("esx_crimejob:refuseRequest")
                SetRequestSearch(false)
                break
            end 
            Citizen.Wait(0)
        end
        running = false
    end)
end

RegisterNetEvent('esx_crimejob:requestSearch', function(target)
    local playerId = GetPlayerFromServerId(target)
    if playerId == -1 then
        return
    end
    exports['esx_rpchat']:PrintToChat("Fouilleren", ("%s wil je fouilleren, druk op ^3^*Y^0^r om dit te accepteren of op ^*^5L^0^r om dit af te wijzen!"):format(target), { r = 255, important = true })
    SetRequestSearch(true, target)
end)

RegisterNetEvent('esx_crimejob:requestRadio', function(target)
    local playerId = GetPlayerFromServerId(target)
    if playerId == -1 then
        return
    end
    exports['esx_rpchat']:PrintToChat("Radio", ("id: %s wil je radio kanaal, druk op ^3^*Y^0^r om dit te accepteren of op ^*^5L^0^r om dit af te wijzen!"):format(target), { r = 255, important = true })
    SetRequestRadio(true, target)
end)

TriggerEvent('chat:addSuggestion', '/request_radio', 'Vraag het laatste portokanaal op', {
    { name="id", help="Het id van de speler" },
})

RegisterCommand("request_radio", function(src, args, raw)
	local target = tonumber(args[1])
	if type(target) == "number" then
        local localTarget = GetPlayerFromServerId(target)
        if localTarget ~= -1 then
            local targetPed = GetPlayerPed(localTarget)
            local targetCoords = GetEntityCoords(targetPed)
            if #(targetCoords - GetEntityCoords(PlayerPedId())) < 20.0 then
                TriggerServerCallback('esx_bikerjob:requestTargetRadioChan', function()
                    EndRadioCheck(target)
                end, target)
            else
                ESX.ShowNotification("Deze persoon is ~r~te ver ~s~weg! Zorg ervoor dat de persoon ~r~binnen 20 meter~s~ staat!")
            end
        else
            ESX.ShowNotification('Persoon niet gevonden')
        end
	else
		ESX.ShowNotification("Voer een geldig id in")
	end
end, false)

local isRequestRadio = false
local runningRadioThread = false
function SetRequestRadio(value, target)
    isRequestRadio = value

    if not isRequestRadio or runningRadioThread then
        return
    end
    runningRadioThread = true
    Citizen.CreateThread(function()
        while isRequestRadio do
            if IsDisabledControlJustReleased(0, 246) then
                local distance = 0
                local target = GetPlayerFromServerId(target)
                if target == -1 then
                    SetRequestRadio(false)
                    return
                end
                distance = #(GetEntityCoords(PlayerPedId()) - GetEntityCoords(GetPlayerPed(target)))
                if distance ~= -1 and distance < 20.0 then
                    ESX.ShowNotification("Verzoek voor radio kanaal geaccepteerd")
                    TriggerServerEvent("esx_crimejob:acceptRadioRequest")
                    SetRequestRadio(false)
                else
                    ESX.ShowNotification("Speler is niet meer dichtbij!")
                    TriggerServerEvent("esx_crimejob:refuseRadioRequest")
                    SetRequestRadio(false)
                    return
                end
            elseif IsDisabledControlJustReleased(0, 182) then
                ESX.ShowNotification("Verzoek voor radio kanaal afgewezen!")
                TriggerServerEvent("esx_crimejob:refuseRadioRequest")
                SetRequestRadio(false)
            end
            Citizen.Wait(0)
        end
        runningRadioThread = false
    end)
end



function EndRadioCheck(target)
    local radio = ServerCallback('esx_bikerjob:getTargetRadioChan', target)
    if radio ~= 0  then
        exports['esx_rpchat']:printToChat("Radio", ("laatste radionummer van de persoon: %s"):format(radio))
    else
        exports['esx_rpchat']:printToChat("Radio", ("De persoon heeft zijn radio niet aangehad"))
    end
end

RegisterNetEvent('esx:playerLoaded', function(xPlayer)
    PlayerData = xPlayer
    RefreshBlips()
    StartKeyListener()
end)

function RefreshJob()
    JobName = PlayerData.job.name
    JobData = PlayerData.job
    if Config.Stations[JobName] ~= nil then
        Stations = Config.Stations[JobName]
    elseif Config.Stations[PlayerData.job2.name] ~= nil then
        JobName = PlayerData.job2.name
        Stations = Config.Stations[PlayerData.job2.name]
        JobData = PlayerData.job2
    end
    RefreshBlips()
    StartKeyListener()
end

RegisterNetEvent('esx:setJob', function(job)
    PlayerData.job = job
    RefreshJob()
end)

RegisterNetEvent('esx:setJob2', function(job)
    PlayerData.job2 = job
    RefreshJob()
end)

-- RegisterNetEvent('esx_phone:loaded')
-- AddEventHandler('esx_phone:loaded', function(phoneNumber, contacts)

--   local specialContact = {
--     name       = 'Biker',
--     number     = 'biker',
--     base64Icon = 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACAAAAAgCAYAAABzenr0AAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAAyJpVFh0WE1MOmNvbS5hZG9iZS54bXAAAAAAADw/eHBhY2tldCBiZWdpbj0i77u/IiBpZD0iVzVNME1wQ2VoaUh6cmVTek5UY3prYzlkIj8+IDx4OnhtcG1ldGEgeG1sbnM6eD0iYWRvYmU6bnM6bWV0YS8iIHg6eG1wdGs9IkFkb2JlIFhNUCBDb3JlIDUuMy1jMDExIDY2LjE0NTY2MSwgMjAxMi8wMi8wNi0xNDo1NjoyNyAgICAgICAgIj4gPHJkZjpSREYgeG1sbnM6cmRmPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5LzAyLzIyLXJkZi1zeW50YXgtbnMjIj4gPHJkZjpEZXNjcmlwdGlvbiByZGY6YWJvdXQ9IiIgeG1sbnM6eG1wPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvIiB4bWxuczp4bXBNTT0iaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wL21tLyIgeG1sbnM6c3RSZWY9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC9zVHlwZS9SZXNvdXJjZVJlZiMiIHhtcDpDcmVhdG9yVG9vbD0iQWRvYmUgUGhvdG9zaG9wIENTNiAoV2luZG93cykiIHhtcE1NOkluc3RhbmNlSUQ9InhtcC5paWQ6NDFGQTJDRkI0QUJCMTFFN0JBNkQ5OENBMUI4QUEzM0YiIHhtcE1NOkRvY3VtZW50SUQ9InhtcC5kaWQ6NDFGQTJDRkM0QUJCMTFFN0JBNkQ5OENBMUI4QUEzM0YiPiA8eG1wTU06RGVyaXZlZEZyb20gc3RSZWY6aW5zdGFuY2VJRD0ieG1wLmlpZDo0MUZBMkNGOTRBQkIxMUU3QkE2RDk4Q0ExQjhBQTMzRiIgc3RSZWY6ZG9jdW1lbnRJRD0ieG1wLmRpZDo0MUZBMkNGQTRBQkIxMUU3QkE2RDk4Q0ExQjhBQTMzRiIvPiA8L3JkZjpEZXNjcmlwdGlvbj4gPC9yZGY6UkRGPiA8L3g6eG1wbWV0YT4gPD94cGFja2V0IGVuZD0iciI/PoW66EYAAAjGSURBVHjapJcLcFTVGcd/u3cfSXaTLEk2j80TCI8ECI9ABCyoiBqhBVQqVG2ppVKBQqUVgUl5OU7HKqNOHUHU0oHamZZWoGkVS6cWAR2JPJuAQBPy2ISEvLN57+v2u2E33e4k6Ngz85+9d++95/zP9/h/39GpqsqiRYsIGz8QZAq28/8PRfC+4HT4fMXFxeiH+GC54NeCbYLLATLpYe/ECx4VnBTsF0wWhM6lXY8VbBE0Ch4IzLcpfDFD2P1TgrdC7nMCZLRxQ9AkiAkQCn77DcH3BC2COoFRkCSIG2JzLwqiQi0RSmCD4JXbmNKh0+kc/X19tLtc9Ll9sk9ZS1yoU71YIk3xsbEx8QaDEc2ttxmaJSKC1ggSKBK8MKwTFQVXRzs3WzpJGjmZgvxcMpMtWIwqsjztvSrlzjYul56jp+46qSmJmMwR+P3+4aZ8TtCprRkk0DvUW7JjmV6lsqoKW/pU1q9YQOE4Nxkx4ladE7zd8ivuVmJQfXZKW5dx5EwPRw4fxNx2g5SUVLw+33AkzoRaQDP9SkFu6OKqz0uF8yaz7vsOL6ycQVLkcSg/BlWNsjuFoKE1knqDSl5aNnmPLmThrE0UvXqQqvJPyMrMGorEHwQfEha57/3P7mXS684GFjy8kreLppPUuBXfyd/ibeoS2kb0mWPANhJdYjb61AxUvx5PdT3+4y+Tb3mTd19ZSebE+VTXVGNQlHAC7w4VhH8TbA36vKq6ilnzlvPSunHw6Trc7XpZ14AyfgYeyz18crGN1Alz6e3qwNNQSv4dZox1h/BW9+O7eIaEsVv41Y4XeHJDG83Nl4mLTwzGhJYtx0PzNTjOB9KMTlc7Nkcem39YAGU7cbeBKVLMPGMVf296nMd2VbBq1wmizHoqqm/wrS1/Zf0+N19YN2PIu1fcIda4Vk66Zx/rVi+jo9eIX9wZGGcFXUMR6BHUa76/2ezioYcXMtpyAl91DSaTfDxlJbtLprHm2ecpObqPuTPzSNV9yKz4a4zJSuLo71/j8Q17ON69EmXiPIlNMe6FoyzOqWPW/MU03Lw5EFcyKghTrNDh7+/vw545mcJcWbTiGKpRdGPMXbx90sGmDaux6sXk+kimjU+BjnMkx3kYP34cXrFuZ+3nrHi6iDMt92JITcPjk3R3naRwZhpuNSqoD93DKaFVU7j2dhcF8+YzNlpErbIBTVh8toVccbaysPB+4pMcuPw25kwSsau7BIlmHpy3guaOPtISYyi/UkaJM5Lpc5agq5Xkcl6gIHkmqaMn0dtylcjIyPThCNyhaXyfR2W0I1our0v6qBii07ih5rDtGSOxNVdk1y4R2SR8jR/g7hQD9l1jUeY/WLJB5m39AlZN4GZyIQ1fFJNsEgt0duBIc5GRkcZF53mNwIzhXPDgQPoZIkiMkbTxtstDMVnmFA4cOsbz2/aKjSQjev4Mp9ZAg+hIpFhB3EH5Yal16+X+Kq3dGfxkzRY+KauBjBzREvGN0kNCTARu94AejBLMHorAQ7cEQMGs2cXvkWshYLDi6e9l728O8P1XW6hKeB2yv42q18tjj+iFTGoSi+X9jJM9RTxS9E+OHT0krhNiZqlbqraoT7RAU5bBGrEknEBhgJks7KXbLS8qERI0ErVqF/Y4K6NHZfLZB+/wzJvncacvFd91oXO3o/O40MfZKJOKu/rne+mRQByXM4lYreb1tUnkizVVA/0SpfpbWaCNBeEE5gb/UH19NLqEgDF+oNDQWcn41Cj0EXFEWqzkOIyYekslFkThsvMxpIyE2hIc6lXGZ6cPyK7Nnk5OipixRdxgUESAYmhq68VsGgy5CYKCUAJTg0+izApXne3CJFmUTwg4L3FProFxU+6krqmXu3MskkhSD2av41jLdzlnfFrSdCZxyqfMnppN6ZUa7pwt0h3fiK9DCt4IO9e7YqisvI7VYgmNv7mhBKKD/9psNi5dOMv5ZjukjsLdr0ffWsyTi6eSlfcA+dmiVyOXs+/sHNZu3M6PdxzgVO9GmDSHsSNqmTz/R6y6Xxqma4fwaS5Mn85n1ZE0Vl3CHBER3lUNEhiURpPJRFdTOcVnpUJnPIhR7cZXfoH5UYc5+E4RzRH3sfSnl9m2dSMjE+Tz9msse+o5dr7UwcQ5T3HwlWUkNuzG3dKFSTbsNs7m/Y8vExOlC29UWkMJlAxKoRQMR3IC7x85zOn6fHS50+U/2Untx2R1voinu5no+DQmz7yPXmMKZnsu0wrm0Oe3YhOVHdm8A09dBQYhTv4T7C+xUPrZh8Qn2MMr4qcDSRfoirWgKAvtgOpv1JI8Zi77X15G7L+fxeOUOiUFxZiULD5fSlNzNM62W+k1yq5gjajGX/ZHvOIyxd+Fkj+P092rWP/si0Qr7VisMaEWuCiYonXFwbAUTWWPYLV245NITnGkUXnpI9butLJn2y6iba+hlp7C09qBcvoN7FYL9mhxo1/y/LoEXK8Pv6qIC8WbBY/xr9YlPLf9dZT+OqKTUwfmDBm/GOw7ws4FWpuUP2gJEZvKqmocuXPZuWYJMzKuSsH+SNwh3bo0p6hao6HeEqwYEZ2M6aKWd3PwTCy7du/D0F1DsmzE6/WGLr5LsDF4LggnYBacCOboQLHQ3FFfR58SR+HCR1iQH8ukhA5s5o5AYZMwUqOp74nl8xvRHDlRTsnxYpJsUjtsceHt2C8Fm0MPJrphTkZvBc4It9RKLOFx91Pf0Igu0k7W2MmkOewS2QYJUJVWVz9VNbXUVVwkyuAmKTFJayrDo/4Jwe/CT0aGYTrWVYEeUfsgXssMRcpyenraQJa0VX9O3ZU+Ma1fax4xGxUsUVFkOUbcama1hf+7+LmA9juHWshwmwOE1iMmCFYEzg1jtIm1BaxW6wCGGoFdewPfvyE4ertTiv4rHC73B855dwp2a23bbd4tC1hvhOCbX7b4VyUQKhxrtSOaYKngasizvwi0RmOS4O1QZf2yYfiaR+73AvhTQEVf+rpn9/8IMAChKDrDzfsdIQAAAABJRU5ErkJggg=='
--   }

--   TriggerEvent('esx_phone:addSpecialContact', specialContact.name, specialContact.number, specialContact.base64Icon)

-- end)

local plates = {
    biker = '76BKR187',
    cartel = '85CRT143',
    mafia = '94MFA841',
    gang = '65GNG926',
    yakuza = '85yak233',
    bratva = '65BRA658',
    peaky = '656PEA98',
    narcos = '72NRC982'
}

AddEventHandler('esx_crimejob:hasEnteredMarker', function(station, part, partNum)
    if part == 'Cloakroom' then
        CurrentAction     = 'menu_cloakroom'
        CurrentActionMsg  = _U('open_cloackroom')
        CurrentActionData = {station = station, partNum = partNum}
    end

    if part == 'Armory' then
        CurrentAction     = 'menu_armory'
        CurrentActionMsg  = _U('open_armory')
        CurrentActionData = {station = station, partNum = partNum}
    end

    if part == 'VehicleSpawner' then
        CurrentAction     = 'menu_vehicle_spawner'
        CurrentActionMsg  = _U('vehicle_spawner')
        CurrentActionData = {station = station, partNum = partNum}
    end

    if part == 'HelicopterSpawner' and (CanUseHelicopter() or Stations[station].Helicopters[partNum].AllowAllGrades) then
        CurrentAction     = 'helicopter_spawner'
        CurrentActionMsg  = _U('helicopter_spawner')
        CurrentActionData = { station = station, partNum = partNum }
    end

    if part == 'VehicleDeleter' then
        local playerPed = PlayerPedId()

        if IsPedInAnyVehicle(playerPed, false) then
            local vehicle = GetVehiclePedIsIn(playerPed, false)

            if DoesEntityExist(vehicle) then
                CurrentAction     = 'delete_vehicle'
                CurrentActionMsg  = _U('store_vehicle')
                CurrentActionData = {vehicle = vehicle, station = station, partNum = partNum}
            end
        end
    end

    if part == 'BossActions' then
        CurrentAction     = 'menu_boss_actions'
        CurrentActionMsg  = _U('open_bossmenu')
        CurrentActionData = {station = station, partNum = partNum}
    end
end)

AddEventHandler('esx_crimejob:hasExitedMarker', function(station, part, partNum)
    ESX.UI.Menu.CloseAll()
    CurrentAction = nil
end)

RegisterNetEvent('esx_crimejob:unrestrain')
AddEventHandler('esx_crimejob:unrestrain', function()
	if isHandcuffed then
		local playerPed = PlayerPedId()
        SetHandcuffed(false)

		ClearPedSecondaryTask(playerPed)
		SetEnableHandcuffs(playerPed, false)
		DisablePlayerFiring(playerPed, false)
		SetPedCanPlayGestureAnims(playerPed, true)
		FreezeEntityPosition(playerPed, false)
		DisplayRadar(true)

		-- end timer
		if handcuffTimer.Active then
			ESX.ClearTimeout(handcuffTimer.Task)
		end
	end
end)

function LoadDict(animDict)
	if not HasAnimDictLoaded(animDict) then
		RequestAnimDict(animDict)

		while not HasAnimDictLoaded(animDict) do
			Citizen.Wait(1)
		end
	end
end

local running = false
function StartHandcuff()
    if running or not isHandcuffed then
        return
    end

    running = true
    Citizen.CreateThread(function()
        while isHandcuffed do
            Citizen.Wait(0)
            if copPed ~= 0 then
                if isDragged then
                    local serverId = GetPlayerFromServerId(copPed)
                    if serverId ~= -1 then
                        local ped = GetPlayerPed(serverId)
                        local myped = PlayerPedId()
                        if IsPedDeadOrDying(ped) or not DoesEntityExist(ped) or IsPedSittingInAnyVehicle(ped) then
                            isDragged = false
                            DetachEntity(myped, true, false)
                            StopAnimTask(myped, walkingAnimDict, walkingAnim, -4.0)
                        else
                            AttachEntityToEntity(myped, ped, 11816, 0.0, 0.64, 0.0, 0.0, 0.0, 0.0, false, false, false, false, 2, true)
                        end

                        local isPlayingAnim = IsEntityPlayingAnim(myped, walkingAnimDict, walkingAnim, 3)
                        local isCopWalking = IsPedWalking(ped)
                        if isCopWalking and not isPlayingAnim then
                            LoadDict(walkingAnimDict)
                            TaskPlayAnim(myped, walkingAnimDict, walkingAnim, 2.0, 2.0, -1, 1, 0, false, false, false)
                        elseif not isCopWalking and isPlayingAnim then
                            StopAnimTask(myped, walkingAnimDict, walkingAnim, -4.0)
                        end
                    end
                elseif copPed then
                    local serverId = GetPlayerFromServerId(copPed)
                    if serverId ~= -1 then
                        local ped = GetPlayerPed(serverId)
                        local playerPed = PlayerPedId()
                        if IsEntityAttachedToEntity(playerPed, ped) then
                            DetachEntity(playerPed, true, false)
                            StopAnimTask(playerPed, walkingAnimDict, walkingAnim, -4.0)
                            copPed = 0
                        end
                    end
                end
            end
            local playerPed = PlayerPedId()
			SetPedMoveRateOverride(playerPed, 0.8)
			DisableControlAction(0, 21, true)

            DisableControlAction(0, 24, true) -- Attack
            DisableControlAction(0, 257, true) -- Attack 2
            DisableControlAction(0, 25, true) -- Aim
            DisableControlAction(0, 263, true) -- Melee Attack 1
            -- DisableControlAction(0, 32, true) -- W
            -- DisableControlAction(0, 34, true) -- A
            -- DisableControlAction(0, 31, true) -- S (fault in Keys table!)
            -- DisableControlAction(0, 30, true) -- D (fault in Keys table!)
            DisableControlAction(0, 137, true)

            DisableControlAction(0, 45, true) -- R
            DisableControlAction(0, 22, true) -- Jump
            DisableControlAction(0, 44, true) -- Cover
            DisableControlAction(0, 37, true) -- Select Weapon
            DisableControlAction(0, 23, true) -- Also 'enter'?

            DisableControlAction(0, 288, true) -- Disable phone
            DisableControlAction(0, 289, true) -- Inventory
            DisableControlAction(0, 170, true) -- Animations
            DisableControlAction(0, 167, true) -- Job

            DisableControlAction(0, 0, true) -- Disable changing view
			DisableControlAction(0, 26, true) -- Disable looking behind
            DisableControlAction(0, 73, true) -- Disable clearing animation
            DisableControlAction(2, 199, true) -- Disable pause screen
            DisableControlAction(1, 244, true) -- Disable Phone

            DisableControlAction(0, 59, true) -- Disable steering in vehicle
            DisableControlAction(0, 71, true) -- Disable driving forward in vehicle
            DisableControlAction(0, 72, true) -- Disable reversing in vehicle

            DisableControlAction(2, 36, true) -- Disable going stealth

            DisableControlAction(0, 264, true) -- Disable melee
            DisableControlAction(0, 257, true) -- Disable melee
            DisableControlAction(0, 140, true) -- Disable melee
            DisableControlAction(0, 141, true) -- Disable melee
            DisableControlAction(0, 142, true) -- Disable melee
            DisableControlAction(0, 143, true) -- Disable melee
            DisableControlAction(0, 75, true)  -- Disable exit vehicle
            DisableControlAction(27, 75, true) -- Disable exit vehicle

            DisableControlAction(0, 56, true) -- F9 (noodknop)

            if IsEntityPlayingAnim(PlayerPedId(), 'mp_arresting', 'idle', 3) ~= 1 then
                ESX.Streaming.RequestAnimDict('mp_arresting', function()
                    TaskPlayAnim(PlayerPedId(), 'mp_arresting', 'idle', 8.0, -8, -1, 49, 0.0, false, false, false)
                end)
            end
        end
        running = false
    end)
end

function SetHandcuffed(value, timer)
	isHandcuffed = value
	TriggerEvent("onHandcuff", isHandcuffed)
    GlobalState.handcuffed = value
	SetResourceKvp(("%s_IsHandcuffed"):format(GetCurrentServerEndpoint()), json.encode(isHandcuffed))
	if value then
		DecorSetBool(PlayerPedId(), "_IS_HANDCUFFED", true)
	else
		DecorRemove(PlayerPedId(), "_IS_HANDCUFFED")
	end
    local playerPed = PlayerPedId()

    Citizen.CreateThread(function()
        Citizen.Wait(0)
        if isHandcuffed then

            RequestAnimDict('mp_arresting')
            while not HasAnimDictLoaded('mp_arresting') do
                Citizen.Wait(100)
            end

            TaskPlayAnim(playerPed, 'mp_arresting', 'idle', 8.0, -8, -1, 49, 0, 0, 0, 0)

            SetEnableHandcuffs(playerPed, true)
            DisablePlayerFiring(playerPed, true)
            SetCurrentPedWeapon(playerPed, `WEAPON_UNARMED`, true) -- unarm player
            SetPedCanPlayGestureAnims(playerPed, false)
            DisplayRadar(false)

            if handcuffTimer.Active then
                ESX.ClearTimeout(handcuffTimer.Task)
            end

            StartHandcuffTimer(timer)
        else
            if handcuffTimer.Active then
                ESX.ClearTimeout(handcuffTimer.Task)
            end

            ClearPedSecondaryTask(playerPed)
            SetEnableHandcuffs(playerPed, false)
            DisablePlayerFiring(playerPed, false)
            SetPedCanPlayGestureAnims(playerPed, true)
            DetachEntity(playerPed, true, false)
            DisplayRadar(true)
        end
    end)
    TriggerEvent("onHandcuff", isHandcuffed)
    StartHandcuff()
end

-- Citizen.CreateThread(function()
--     local shouldShowNotification = false
--     local count = 0
--     while true do
--         local playerPed = PlayerPedId()
--         count = count + 1
--         if IsPedArmed(playerPed, 1) then
--             local playerCoords = GetEntityCoords(playerPed)
--             local closePed, distance = ESX.Game.GetClosestPed(playerCoords, {playerPed})
--             if count > 20 then
--                 if closePed and closePed ~= 0 and distance < 2.0 and IsEntityHandcuffed(closePed, GetPlayerServerId(closePed)) then
--                     shouldShowNotification = true
--                 else
--                     Citizen.Wait(distance * 15)
--                     shouldShowNotification = false
--                 end
--                 count = 0
--             end
--             if shouldShowNotification then
--                 local targetCoords = GetEntityCoords(closePed) + vector3(0, 0, 1.0)
--                 ESX.ShowFloatingHelpNotification("Druk op    ~INPUT_CONTEXT~om te ontboeien", targetCoords)
--                 if IsControlJustReleased(1, 38) then
--                 end
--             end
--         else
--             Citizen.Wait(1500)
--         end
--         Citizen.Wait(0)
--     end
-- end)

---comment
---@param timer integer cuff degrading timer value in milliseconds
function StartHandcuffTimer(timer)
    timer = timer or Config.HandcuffTimer
	if handcuffTimer.Active then
		ESX.ClearTimeout(handcuffTimer.Task)
	end

	handcuffTimer.Active = true

	handcuffTimer.Task = ESX.SetTimeout(timer, function()
		ESX.ShowNotification(_U('unrestrained_timer'))
		TriggerEvent('esx_crimejob:unrestrain')
		handcuffTimer.Active = false
	end)
end

RegisterNetEvent('esx_crimejob:handcuff')
AddEventHandler('esx_crimejob:handcuff', function(cuff)
    if cuff ~= isHandcuffed then
        SetHandcuffed(not isHandcuffed)
    end
end)

AddEventHandler('playerSpawned', function()
    if isHandcuffed then
        TriggerEvent('esx_crimejob:handcuff')
    end

    if isDragged then
        TriggerEvent('esx_crimejob:drag')
    end
end)

RegisterNetEvent('esx_crimejob:drag')
AddEventHandler('esx_crimejob:drag', function(cop)
    TriggerServerEvent('esx:clientLog', 'starting dragging')
    isDragged = not isDragged
    copPed = tonumber(cop)
end)

RegisterNetEvent('esx_crimejob:putInVehicle')
AddEventHandler('esx_crimejob:putInVehicle', function()
    local playerPed = PlayerPedId()
	local coords = GetEntityCoords(playerPed)

	if IsAnyVehicleNearPoint(coords, 5.0) then
		local vehicle, distance = ESX.Game.GetClosestVehicle()

		if distance < 4.0 and DoesEntityExist(vehicle) then
			local maxSeats, freeSeat = GetVehicleMaxNumberOfPassengers(vehicle)

			for i=maxSeats - 1, 0, -1 do
				if IsVehicleSeatFree(vehicle, i) then
					freeSeat = i
					break
				end
			end

			if freeSeat then
				DetachEntity(playerPed, true, false)
				TaskWarpPedIntoVehicle(playerPed, vehicle, freeSeat)
				isDragged = false
			end
		end
	end
end)

RegisterNetEvent('esx_crimejob:OutVehicle')
AddEventHandler('esx_crimejob:OutVehicle', function()
    local ped = PlayerPedId()

    
	if not IsPedSittingInAnyVehicle(ped) then
		return
	end

    local vehicle = GetVehiclePedIsIn(ped, false)
    TaskLeaveVehicle(ped, vehicle, 256)
end)

-- Create blips
function RefreshBlips()
    if blips['blip_job'] ~= nil then
        RemoveBlip(blips['blip_job'])
        blips['blip_job'] = nil
    end
    if isPlayerWhitelisted() then
        for k,v in pairs(Stations) do
            local blip = AddBlipForCoord(v.Blip.Pos.x, v.Blip.Pos.y, v.Blip.Pos.z)
            SetBlipSprite (blip, v.Blip.Sprite)
            SetBlipDisplay(blip, v.Blip.Display)
            SetBlipScale  (blip, v.Blip.Scale)
            SetBlipColour (blip, v.Blip.Colour)
            SetBlipAsShortRange(blip, true)

            local textEntry = "_MAP_BLIP_BIKER_" .. k
            AddTextEntry(textEntry, v.Blip.Name or _U('map_blip'))
            BeginTextCommandSetBlipName(textEntry)
            EndTextCommandSetBlipName(blip)

            blips["blip_job"] = blip
        end
    end
end

local function markerTick(thread)
    if not isPlayerWhitelisted() then
        thread:stop()
        return
    end

    local markerSize = Config.MarkerSize.x
    local markerSizey = Config.MarkerSize.y
    local markerSizez = Config.MarkerSize.z
    local markerType = Config.MarkerType
    local playerPed      = PlayerPedId()
    local coords         = GetEntityCoords(playerPed)
    local minDistance    = 100000
    local isInMarker     = false
    local currentStation = nil
    local currentPart    = nil
    local currentPartNum = nil

    for k=1, #Stations do
        local v = Stations[k]

        if v.Armories then
            for i2=1, #v.Armories do
                local v2 = v.Armories[i2]
                local distance = #(coords - v2)
                if distance < drawDistance then
                    DrawMarker(markerType, v.Armories[i2].x, v.Armories[i2].y, v.Armories[i2].z, 0.0, 0.0, 0.0, 0, 0.0, 0.0, markerSize, markerSizey, markerSizez, Config.MarkerColor.r, Config.MarkerColor.g, Config.MarkerColor.b, 100, false, true, 2, false, false, false, false)
                    if distance < markerSize then
                        isInMarker     = true
                        currentStation = k
                        currentPart    = 'Armory'
                        currentPartNum = i2
                    end
                end
                minDistance = min(minDistance, distance)
            end
        end

        if v.Vehicles then
            for i2=1, #v.Vehicles do
                local v2 = v.Vehicles[i2]
                local distance = #(coords - v2.Spawner)

                if distance < drawDistance then
                    DrawMarker(markerType, v.Vehicles[i2].Spawner.x, v.Vehicles[i2].Spawner.y, v.Vehicles[i2].Spawner.z, 0.0, 0.0, 0.0, 0, 0.0, 0.0, markerSize * 2, markerSizey * 2, markerSizez, Config.MarkerColor.r, Config.MarkerColor.g, Config.MarkerColor.b, 100, false, true, 2, false, false, false, false)
                    if distance < markerSize then
                        isInMarker     = true
                        currentStation = k
                        currentPart    = 'VehicleSpawner'
                        currentPartNum = i2
                    end
                end
                minDistance = min(minDistance, distance)

                distance = #(coords - v2.SpawnPoint)

                if distance < markerSize then
                    isInMarker     = true
                    currentStation = k
                    currentPart    = 'VehicleSpawnPoint'
                    currentPartNum = i2
                end
                minDistance = min(minDistance, distance)
            end
        end

        if v.Helicopters then
            for i2=1, #v.Helicopters do
                local v2 = v.Helicopters[i2]
                local distance = #(coords - v2.Spawner)

                if distance < drawDistance and (v2.AllowAllGrades or CanUseHelicopter()) then
                    DrawMarker(markerType, v2.Spawner.x, v2.Spawner.y, v2.Spawner.z, 0.0, 0.0, 0.0, 0, 0.0, 0.0, markerSize, markerSizey, markerSizez, Config.MarkerColor.r, Config.MarkerColor.g, Config.MarkerColor.b, 100, false, true, 2, false, false, false, false)
                    if distance < markerSize then
                        isInMarker     = true
                        currentStation = k
                        currentPart    = 'HelicopterSpawner'
                        currentPartNum = i2
                    end
                end
                minDistance = min(minDistance, distance)

                -- distance = #(coords - v2.SpawnPoint)
                -- if distance < markerSize then
                --     isInMarker     = true
                --     currentStation = k
                --     currentPart    = 'HelicopterSpawnPoint'
                --     currentPartNum = i2
                -- end
                minDistance = min(minDistance, distance)
            end
        end

        if v.VehicleDeleters then
            for i2=1, #v.VehicleDeleters do
                local v2 = v.VehicleDeleters[i2]
                local distance = #(coords - v2)
                if distance < drawDistance then
                    DrawMarker(markerType, v.VehicleDeleters[i2].x, v.VehicleDeleters[i2].y, v.VehicleDeleters[i2].z, 0.0, 0.0, 0.0, 0, 0.0, 0.0, markerSize * 3, markerSizey * 3, markerSizez, Config.MarkerColor.r, Config.MarkerColor.g, Config.MarkerColor.b, 100, false, true, 2, false, false, false, false)
                    if distance < (markerSize * 3) then
                        isInMarker     = true
                        currentStation = k
                        currentPart    = 'VehicleDeleter'
                        currentPartNum = i2
                    end
                end
                minDistance = min(minDistance, distance)
            end
        end

        if Config.EnablePlayerManagement and v.BossActions then
            for i2=1, #v.BossActions do
                local v2 = v.BossActions[i2]
                local distance = #(coords - v2)
                if distance < drawDistance then
                    DrawMarker(markerType, v.BossActions[i2].x, v.BossActions[i2].y, v.BossActions[i2].z, 0.0, 0.0, 0.0, 0, 0.0, 0.0, markerSize, markerSizey, markerSizez, Config.MarkerColor.r, Config.MarkerColor.g, Config.MarkerColor.b, 100, false, true, 2, false, false, false, false)
                    if distance < markerSize then
                        isInMarker     = true
                        currentStation = k
                        currentPart    = 'BossActions'
                        currentPartNum = i2
                    end
                end
                minDistance = min(minDistance, distance)
            end
        end
    end

    local hasExited = false
    if isInMarker and not hasAlreadyEnteredMarker or (isInMarker and (lastStation ~= currentStation or lastPart ~= currentPart or lastPartNum ~= currentPartNum) ) then

        if
        (lastStation ~= nil and lastPart ~= nil and lastPartNum ~= nil) and
        (lastStation ~= currentStation or lastPart ~= currentPart or lastPartNum ~= currentPartNum)
        then
            TriggerEvent('esx_crimejob:hasExitedMarker', lastStation, lastPart, lastPartNum)
            hasExited = true
        end

        hasAlreadyEnteredMarker = true
        lastStation             = currentStation
        lastPart                = currentPart
        lastPartNum             = currentPartNum
        TriggerEvent('esx_crimejob:hasEnteredMarker', currentStation, currentPart, currentPartNum)
    end

    if not hasExited and not isInMarker and hasAlreadyEnteredMarker then
        hasAlreadyEnteredMarker = false
        TriggerEvent('esx_crimejob:hasExitedMarker', lastStation, lastPart, lastPartNum)
    end

    if minDistance > drawDistance then
        return 12 * minDistance ^ 1.2
    end
end

---@type Thread
local markerThread = Thread(markerTick, "markerThread")
markerThread:useTicker()
markerThread:stopTicker()


-- Enter / Exit marker events
-- Display Markers
local function drawMarkers()
    markerThread:start()
end

function GetJobPlate()
    if plates[JobName] and string.len(plates[JobName]) > 0 then
        return plates[JobName]
    end
end

local function SpawnHelicopter(helicopters)
    if IsBusy then
        ESX.ShowNotification("~r~Een moment geduld...~s~ Probeer het over enkele seconden opnieuw!")
        return
    end
    local state, err = xpcall(function()
        IsBusy = true
        RequestModel(`maverick`)
        while not HasModelLoaded(`maverick`) do
            RequestModel(`maverick`)
            Citizen.Wait(100)
        end
        local min, max = GetModelDimensions(`maverick`)
        SetModelAsNoLongerNeeded(`maverick`)
        local x = math.abs(min.x) + math.abs(max.x)
        local y = math.abs(min.y) + math.abs(max.y)
        local z = math.abs(min.z) + math.abs(max.z)
        local maxValue = math.max(x, y, z)
        if
                not IsAnyVehicleNearPoint(helicopters.SpawnPoint.x, helicopters.SpawnPoint.y, helicopters.SpawnPoint.z,  3.0)
                and ESX.Game.IsSpawnPointClear(helicopters.SpawnPoint, maxValue)
        then
            local jobPlate = GetJobPlate()
            ESX.Game.SpawnVehicle(helicopters.Model or 'maverick', {
                x = helicopters.SpawnPoint.x,
                y = helicopters.SpawnPoint.y,
                z = helicopters.SpawnPoint.z
            }, helicopters.Heading, function(vehicle)
                DecorSetInt(vehicle, 'Owned_Vehicle', 1)
                SetVehicleModKit(vehicle, 0)
                SetVehicleLivery(vehicle, 0)
    
                if jobPlate then
                    SetVehicleNumberPlateText(vehicle, jobPlate)
                    TriggerEvent('esx_vehiclelock:registerkeyjob', jobPlate)
                end
    
                TriggerEvent('esx_jobs:spawnedVehicle', vehicle)
                IsBusy = false
            end, {
                plate = jobPlate,
                errCb = function()
                    IsBusy = false
                end
            })
        else
            ESX.ShowNotification('Er is geen plek')
        end
    end, Traceback)
    if not state then
        IsBusy = false
    end
end

--- Gets the vehicles in the given society garage
--- @param jobName string The job to get the garage of, defaults to current job (JobName)
function GetVehiclesInSocietyGarage(jobName)
    jobName = jobName or JobName
    local vehicles = ServerCallback('esx_crimejob:getVehiclesInGarageMinimized', JobName)

    return vehicles
end

--- Deletes the given vehicle, this does not store it in the society garage
--- @param vehicle Entity The vehicle to delete
--- @see StoreVehicleInSocietyGarage
function DeleteVehicle(vehicle)
    local plate = ESX.Math.Trim(GetVehicleNumberPlateText(vehicle))
    local data = {
        shouldUpdate = true,
        returnToGarage = true,
        callingSource = 'esx_bikerjob:delete_vehicle',
        netId = NetworkGetNetworkIdFromEntity(vehicle),
        delete = true
    }
    TriggerServerEvent('eden_garage:removeFromList', plate, data)
    TriggerEvent('eden_garage:removeFromList', plate)
    if plate:gsub("  ", " ") ~= plate then
        TriggerServerEvent("eden_garage:removeFromList", plate:gsub("  ", " "), data)
        TriggerEvent('eden_garage:removeFromList', plate:gsub("  ", " "))
    end


    local start = GetGameTimer()
    while DoesEntityExist(vehicle) and GetGameTimer() - start < 10000 do
        if GetGameTimer() - start > 2000 then
            exports['guidehud']:tutorial(_U('deleting_vehicle'))
        end
        Citizen.Wait(0)
    end
    exports['guidehud']:clearTutorial()
    Citizen.Wait(1000)

    if DoesEntityExist(vehicle) then
        ESX.Game.TryDeleteAny(vehicle)
    end
end

function RemoveVehicleFromGarage(vehicleProps)
    TriggerServerEvent('esx_crimejob:removeVehicleFromGarage', vehicleProps.plate)
end

function PutVehicleInGarage(vehicleProps)
    return ServerCallback('esx_crimejob:putVehicleInGarage', vehicleProps)
end

--- Stores and deletes the given entity, only stores the vehicle if needed, so doesn't store gang helicopters, just deletes them
--- @param vehicle Entity The vehicle to store in the society garage and delete
--- @see DeleteVehicle
function StoreVehicleInSocietyGarage(vehicle)
    vehicle = Entity(vehicle)
    local state = vehicle.state.singleUse
    if DecorGetBool(vehicle, "_SINGLE_USE") and not state then
        TriggerServerEvent("SentryIO:Warning", ("Mismatch between decor and state bag!"), ("State bag is %s and decor is %s"):format(state, DecorGetBool(vehicle, "_SINGLE_USE")), GetCurrentResourceName(), { resource = GetCurrentResourceName() })
        ESX.ShowNotification("De state bags en het decor komen niet overeen")
        exports['esx_rpchat']:printToChat("GARAGE", "De state bag en het decor komen niet overeen, als je een verband vind wat dit kan veroorzaken zou je dan een ticket aan kunnen maken hoe ik dit kan herproduceren.", { r = 255 })
    end
    if DecorGetBool(vehicle, "_SINGLE_USE") or state then
        ESX.ShowNotification("Dit voertuig kun je niet in de opslag plaatsen.")
        return
    end
    local vehicleProps = ESX.Game.GetVehicleProperties(vehicle)

    local count = 0
    local isGangHelicopter = vehicleProps.plate == GetJobPlate()
    if not isGangHelicopter then
        local garage = GetVehiclesInSocietyGarage()
        for _,v in pairs(garage) do
            count = count + 1
            if not v.plate then
                print("^1ERROR: ^7 Plate is null for vehicle!")
            end
            if v.plate and v.plate:gsub("[^%w%d]", "") == vehicleProps.plate:gsub("[^%w%d]", "") then
                ESX.ShowNotification("Deze auto staat al in de garage")
                return
            end
        end
        if count >= Config.VehicleLimit then
            ESX.ShowNotification(("Je hebt de limiet van %s auto's bereikt"):format(Config.VehicleLimit))
            return
        end
    end

    local result = true
    -- Don't put the Helicopter of this gang into their own storage
    if not isGangHelicopter then
        for k,v in pairs(vehicleProps) do
            if v == -1 then
                vehicleProps[k] = nil
            end
        end

        result = PutVehicleInGarage(vehicleProps)
        ESX.ShowNotification(("De auto staat in de opslag (%i/%s)"):format(count + 1, Config.VehicleLimit))
    else
        ESX.ShowNotification("Het voertuig is veilig teruggezet")
    end

    if result then
        DeleteVehicle(vehicle)
    end
end

function CanUseShop()
    local job = JobData
    if job.permissions then
        if job.permissions.shop == false then
            return false
        end
    end

    return true
end

function CanMangageLicense()
    local job = JobData
    if job.permissions then
        if job.permissions.license == true then
            return true
        end
    end

    return false
end

function CanUseStorage()
    local job = JobData
    if job.permissions then
        if job.permissions.storage == false then
            return false
        end
    end

    return true
end

function CanPutInStorage()
    local job = JobData
    if job.permissions then
        if job.permissions.insert == false then
            return false
        end
    end

    return true
end

function CanUseGarage()
    local job = JobData
    if job.permissions then
        if job.permissions.garage == false then
            return false
        end
    end

    return true
end

function HasJob(job)
    return JobName == job
end

function HasGrade(grade)
    return JobData.grade_name == grade
end

function CanUseHelicopter()
    local job = JobData
    if job.permissions then
        if job.permissions.heli == true then
            return true
        end
    end
    if HasGrade('boss') or HasGrade('reporter') then
        return true
    end

    return false
end

function CanUseActionsMenu()
    local job = JobData
    if job.permissions then
        if job.permissions.actions == false then
            return false
        end
    end

    return true
end

-- Key Controls
local function KeyListener()
    keyRunning = true
    Citizen.CreateThread(function()
        while isPlayerWhitelisted() do
            Citizen.Wait(0)
            if CurrentAction ~= nil then
                SetTextComponentFormat('STRING')
                AddTextComponentString(CurrentActionMsg)
                DisplayHelpTextFromStringLabel(0, 0, 1, -1)

                if IsControlJustReleased(0, 38) and isPlayerWhitelisted() then
                    if CurrentAction == 'menu_cloakroom' then
                        OpenCloakroomMenu()
                    elseif CurrentAction == 'menu_armory' then
                        OpenArmoryMenu(CurrentActionData.station)
                    elseif CurrentAction == 'menu_vehicle_spawner' then
                        if CanUseGarage() then
                            OpenVehicleSpawnerMenu(CurrentActionData.station, CurrentActionData.partNum)
                        else
                            ESX.ShowNotification("Je hebt hier geen permissies voor")
                        end
                    elseif CurrentAction == 'helicopter_spawner' then
                        local helicopters = Stations[CurrentActionData.station].Helicopters
                        local partNum = CurrentActionData.partNum

                        local isOnEarth, netId = table.unpack(exports['esx_jb_eden_garage2']:isCarOnEarth(plates[JobName]))
                        if not isOnEarth then
                            SpawnHelicopter(helicopters[partNum])
                        else
                            exports['esx_rpchat']:printToChat("Helikopter", "Dit voertuig is nog ergens aanwezig! Gebruik ^2/getvehicle " .. plates[JobName] .. "^7")
                        end
                        
                    elseif CurrentAction == 'delete_vehicle' then
                        if CanUseGarage() then
                            if Config.EnableSocietyOwnedVehicles and (Stations[CurrentActionData.station].UseSocietyVehicles == nil or Stations[CurrentActionData.station].UseSocietyVehicles) then
                                StoreVehicleInSocietyGarage(CurrentActionData.vehicle)
                            else
                                DeleteVehicle(CurrentActionData.vehicle)
                            end
                        else
                            ESX.ShowNotification("Je hebt hier geen permissies voor")
                        end
                    elseif CurrentAction == 'menu_boss_actions' then
                        ESX.UI.Menu.CloseAll()

                        local options = { wash = Stations[CurrentActionData.station].HasMoneyLaundering }

                        TriggerEvent('esx_society:openBossMenu', JobName, function(data, menu)
                            menu.close()

                            CurrentAction     = 'menu_boss_actions'
                            CurrentActionMsg  = _U('open_bossmenu')
                            CurrentActionData = CurrentActionData
                        end, options)
                    elseif CurrentAction == 'remove_entity' then
                        DeleteEntity(CurrentActionData.entity)
                    end

                    CurrentAction = nil
                end
            end

            -- 167 F6
            if not OnDuty and CanUseActionsMenu() and IsControlJustReleased(0, 167) and not ESX.UI.Menu.IsOpen('default', GetCurrentResourceName(), 'biker_actions')  and Config.Stations[JobName][1].HasJobMenu then
                OpenBikerActionsMenu()
            end
        end
        keyRunning = false
    end)
end

function StartKeyListener()
    if not keyRunning then
        KeyListener()
    end
    drawMarkers()
end

RegisterNetEvent('esx_crimejob:useLockpick')
AddEventHandler('esx_crimejob:useLockpick', function()
    local player, distance = ESX.Game.GetClosestPlayer()
    if distance > 3.0 then
        ESX.ShowNotification("~r~Geen speler dichtbij!~s~")
        return
    end

    local targetPed = GetPlayerPed(player)
    if not DecorGetBool(targetPed, "_IS_HANDCUFFED") then
        ESX.ShowNotification("~r~Deze speler is niet geboeid!")
        return
    end

    ServerId = GetPlayerServerId(player)
    local playerHeading = GetEntityHeading(PlayerPedId())
    local playerVector = GetEntityForwardVector(PlayerPedId())
    local playerCoords = GetEntityCoords(PlayerPedId())
    TriggerServerEvent('esx_crimejob:doLockpick', ServerId, playerHeading, playerCoords, playerVector)
end)

AddEventHandler('onResourceStop', function(resource)
	if resource == GetCurrentResourceName() then

		if handcuffTimer.Active then
			ESX.ClearTimeout(handcuffTimer.Task)
		end
	end
end)

function LoadAnimDict(dictname)
	if not HasAnimDictLoaded(dictname) then
		RequestAnimDict(dictname) 
		while not HasAnimDictLoaded(dictname) do 
			Citizen.Wait(1)
		end
	end
end

local usableControlsDuringLockpicking = {
    249, 0, 1, 2, 3, 4, 5, 6
}

RegisterNetEvent('esx_crimejob:lockpickSource')
AddEventHandler('esx_crimejob:lockpickSource', function()
	Citizen.Wait(250)
    LoadAnimDict("mp_arresting")
    local isUncuffing = true
    local cancelled = false
    TaskPlayAnim(PlayerPedId(), 'mp_arresting', 'a_uncuff', 8.0, 8.0, -1, 0, 0.0, 0, 0, 0)
    Citizen.CreateThread(function()
        while isUncuffing do
            DisableAllControlActions(0)
            for i=1, #usableControlsDuringLockpicking do
                EnableControlAction(0, usableControlsDuringLockpicking[i], true)
            end
            if IsDisabledControlJustReleased(0, 73) then
                cancelled = true
                break
            end
            Citizen.Wait(0)
        end
    end)
    Citizen.Wait(1000)
    local start = GetGameTimer()
    while GetGameTimer() - start < 15000 and not cancelled do
        Citizen.Wait(1000)
        if cancelled then
            break
        end
        Citizen.Wait(1000)
        if cancelled then
            break
        end
        local coords = GetEntityCoords(PlayerPedId())
        local rotation = GetEntityRotation(PlayerPedId())
        TaskPlayAnimAdvanced(PlayerPedId(), 'mp_arresting', 'a_uncuff', coords, rotation, 1.0, 1.0, -1, 0, 0.2)
    end
    isUncuffing = false
    ClearPedTasks(PlayerPedId())
    RemoveAnimDict('mp_arresting')
    if cancelled then
        TriggerServerEvent('esx_crimejob:lockpickingCancelled', ServerId)
        return
    end
    TriggerServerEvent('esx_crimejob:unCuffLockpick', ServerId)
end)

RegisterNetEvent('esx_crimejob:lockpickingCancelled')
AddEventHandler('esx_crimejob:lockpickingCancelled', function()
    Cancelled = true
end)

RegisterNetEvent('esx_crimejob:lockpickTarget')
AddEventHandler('esx_crimejob:lockpickTarget', function(playerHeading, playerCoords, playerVector)
	local x, y, z = table.unpack(playerCoords + playerVector * 1.0)
	SetEntityCoordsNoOffset(PlayerPedId(), x, y, z)
	SetEntityHeading(PlayerPedId(), playerHeading)
	Citizen.Wait(250)
	LoadAnimDict('mp_arresting')
    local isBeingUncuffed = true
    Cancelled = false
    TaskPlayAnim(PlayerPedId(), 'mp_arresting', 'b_uncuff', 8.0, 8.0, -1, 0, 0, 0, 0, 0)
    Citizen.CreateThread(function()
        while isBeingUncuffed do
            DisableAllControlActions(0)
            for i=1, #usableControlsDuringLockpicking do
                EnableControlAction(0, usableControlsDuringLockpicking[i], true)
            end
            if Cancelled then
                break
            end
            Citizen.Wait(0)
        end
    end)
    Citizen.Wait(1000)
    local start = GetGameTimer()
    while GetGameTimer() - start < 15000 do
        Citizen.Wait(1000)
        if Cancelled then
            break
        end
        Citizen.Wait(1000)
        if Cancelled then
            break
        end
        local coords = GetEntityCoords(PlayerPedId())
        local rotation = GetEntityRotation(PlayerPedId())
        TaskPlayAnimAdvanced(PlayerPedId(), 'mp_arresting', 'b_uncuff', coords, rotation, 1.0, 1.0, -1, 0, 0.2)
    end
    isBeingUncuffed = false
	ClearPedTasks(PlayerPedId())
    RemoveAnimDict('mp_arresting')
end)

---------------------------------------------------------------------------------------------------------
--NB : gestion des menu
---------------------------------------------------------------------------------------------------------

RegisterNetEvent('NB:openMenuBiker', function()
    if not CanUseActionsMenu() then
        return
    end
    OpenBikerActionsMenu()
end)