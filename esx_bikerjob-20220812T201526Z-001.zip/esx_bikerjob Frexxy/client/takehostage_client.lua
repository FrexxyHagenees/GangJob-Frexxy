local beingHeldHostage, holdingHostage = false, false
local hostageTarget = nil

local hostageAllowedWeapons = {
	[`WEAPON_PISTOL`] = true,
	[`WEAPON_PISTOL_MK2`] = true,
	[`WEAPON_MINISMG`] = true,
}

local takeHostageAnimNamePlaying = ""
local takeHostageAnimDictPlaying = ""
local takeHostageControlFlagPlaying = 0
local hostagedPed = nil

local safezones = {
	{ coords = vector3(-544.67, -204.95, 38.21), radius = 50.0 },
	{ coords = vector3(232.44, -792.19, 33.39), radius = 33.0 },
	{ coords = vector3(1792.25, 2483.09, -122.35), radius = 100.0 },
	{ coords = vector3(1011.16, -3102.58, -39.03), radius = 100.0 },
	{ coords = vector3(1701, 2575.76, -69), radius = 60.0 }
}
local interiorSafeZones = {
	[275969] = {  },
	[276225] = {  },
}

function IsStandingBehindPed(ped)
	if IsPedRagdoll(ped) then
		return true
	end
	local offset = GetOffsetFromEntityGivenWorldCoords(ped, GetEntityCoords(PlayerPedId()))

	if offset.y < 0 then
		return true
	end

	return false
end

function IsStandingBehindPlayer(player)
	return IsStandingBehindPed(GetPlayerPed(player))
end

function LoadAnimDict(dict)
	RequestAnimDict(dict)
	local start = GetGameTimer()
	while not HasAnimDictLoaded(dict) and GetGameTimer() - start < 5000 do
		Citizen.Wait(10)
	end
end

RegisterNetEvent("takehostage:startMe", function(target)
	local animationLib = 'anim@gangops@hostage@'
	local animation = 'perp_idle'
	local length = 100000
	local playerPed = PlayerPedId()
	local controlFlag = 49
	hostageTarget = target
	ClearPedSecondaryTask(playerPed)
	SetPedCanRagdoll(playerPed, false)
	LoadAnimDict(animationLib)

	TaskPlayAnim(playerPed, animationLib, animation, 8.0, -8.0, length, controlFlag, 0, false, false, false)
	takeHostageAnimNamePlaying = animation
	takeHostageAnimDictPlaying = animationLib
	takeHostageControlFlagPlaying = controlFlag
end)

RegisterNetEvent("takehostage:startTarget", function(source)
	local playerPed = PlayerPedId()
	local sourcePlayer = GetPlayerFromServerId(source)
	local sourcePed = GetPlayerPed(sourcePlayer)
	SetPedCanRagdoll(playerPed, false)
	GetSetHostagePed(sourcePed)
	local length = 100000
	local animationLib = 'anim@gangops@hostage@'
	local animation2 = 'victim_idle'
	local distance = 0.11 --Higher = closer to camera
	local distance2 = -0.24 --higher = left
	local height = 0.0
	local spin = 0.0
	local controlFlag = 49

	beingHeldHostage = true
	LoadAnimDict(animationLib)

	AttachEntityToEntity(playerPed, sourcePed, 39317, distance2, distance, height, 0.5, 0.5, spin, false, true, false, false, 2, false)

	if controlFlag == nil then controlFlag = 0 end

	TaskPlayAnim(playerPed, animationLib, animation2, 8.0, -8.0, length, controlFlag, 0, false, false, false)
	takeHostageAnimNamePlaying = animation2
	takeHostageAnimDictPlaying = animationLib
	takeHostageControlFlagPlaying = controlFlag
end)

function GetSetHostagePed(_ped)
	hostagedPed = _ped or hostagedPed
	return hostagedPed
end

local walkingAnimDict = "anim@move_m@grooving@"
local walkingAnim = "walk"
Citizen.CreateThread(function()
	while true do
		if holdingHostage or beingHeldHostage then
			local playerPed = PlayerPedId()
			while not IsEntityPlayingAnim(playerPed, takeHostageAnimDictPlaying, takeHostageAnimNamePlaying, 3) do
				TaskPlayAnim(playerPed, takeHostageAnimDictPlaying, takeHostageAnimNamePlaying, 8.0, -8.0, 100000, takeHostageControlFlagPlaying, 0, false, false, false)
				Citizen.Wait(0)
			end
			if beingHeldHostage then
				local targetPed = playerPed
				if targetPed then
					local hostagePed = GetSetHostagePed()
					local isWalking = IsPedWalking(hostagePed)
					local isPlayingWalkAnim = IsEntityPlayingAnim(targetPed, walkingAnimDict, walkingAnim, 3)
					if isWalking and not isPlayingWalkAnim then
						LoadAnimDict(walkingAnimDict)
						TaskPlayAnim(targetPed, walkingAnimDict, walkingAnim, 8.0, 8.0, -1, 1, 0, false, false, false)
					elseif not isWalking and isPlayingWalkAnim then
						StopAnimTask(targetPed, walkingAnimDict, walkingAnim, -4.0)
					end
				end
			end
		else
			Citizen.Wait(1000)
		end
		Citizen.Wait(0)
	end
end)

function GetClosestPlayer(radius)
	local players = GetActivePlayers()
	local closestDistance = -1
	local closestPlayer = -1
	local ply = PlayerPedId()
	local plyCoords = GetEntityCoords(ply, 0)

	for index, value in ipairs(players) do
		local target = GetPlayerPed(value)
		if(target ~= ply) then
			local targetCoords = GetEntityCoords(GetPlayerPed(value), 0)
			local distance = #(targetCoords - plyCoords)
			if(closestDistance == -1 or closestDistance > distance) then
				closestPlayer = value
				closestDistance = distance
			end
		end
	end
	--print("closest player is dist: " .. tostring(closestDistance))
	if closestDistance <= radius then
		return closestPlayer
	else
		return nil
	end
end

local hostageControlsToDisable = {
	21,		-- disable sprint
	24,		-- disable attack
	25,		-- disable aim
	47,		-- disable weapon
	58,		-- disable weapon
	37,     -- disable weaponwheel
	140,	-- disable melee
	141,	-- disable melee
	142,	-- disable melee
	143,	-- disable melee
	257,	-- disable melee
	263,	-- disable melee
	264,	-- disable melee
	75,		-- disable exit vehicle
	22,		-- disable jump
	32,		-- disable move up
	268,	-- disable move up
	33,		-- disable move down
	269,	-- disable move down
	34,		-- disable move left
	270,	-- disable move left
	35,		-- disable move right
	271,	-- disable move right
	326,     -- disable duck control
}

local hostageTakerControlsToDisable = {
	24,		-- disable attack
	25,		-- disable aim
	47,		-- disable weapon
	58,		-- disable weapon
	37,     -- disable weaponwheel
	140,	-- disable melee
	141,	-- disable melee
	142,	-- disable melee
	143,	-- disable melee
	257,	-- disable melee
	263,	-- disable melee
	264,	-- disable melee
	75,		-- disable exit vehicle
	21,     -- disable sprint
	22,		-- disable jump
	326,     -- disable duck control
	74,     -- disable h (whistle)
}

Citizen.CreateThread(function()
	while true do
		local sleep = 1000
		local isInSafeZone = false
		local playerPed = PlayerPedId()
		local coords = GetEntityCoords(playerPed)
		for i=1, #safezones do
			if (#(safezones[i].coords - coords) < safezones[i].radius) then
				isInSafeZone = true
			end
		end
		local interior = GetInteriorFromEntity(playerPed)
		if interiorSafeZones[interior] then
			isInSafeZone = true
		end
		if holdingHostage then
			sleep = 0
			if IsEntityDead(playerPed) then
				ReleaseHostage()
			end
			for i=1, #hostageTakerControlsToDisable do
				DisableControlAction(0, hostageTakerControlsToDisable[i], true)
			end
			DisablePlayerFiring(playerPed, true)
			local playerCoords = GetEntityCoords(playerPed)
			DrawText3D(playerCoords.x, playerCoords.y, playerCoords.z, "Druk op [H] om te laten gaan, [G] om te vermoorden.")
			if IsDisabledControlJustPressed(0,74) then --release
				ReleaseHostage()
			elseif IsDisabledControlJustPressed(0,47) then --kill
				if not isInSafeZone then
					KillHostage()
				elseif isInSafeZone then
					ReleaseHostage()
					ESX.ShowNotification("Je bevind je in een safezone!")
				end
			end
		end
		if beingHeldHostage then
			sleep = 0
			for i=1, #hostageControlsToDisable do
				DisableControlAction(0, hostageControlsToDisable[i], true)
			end
		end
		Citizen.Wait(sleep)
	end
end)

function DrawText3D(x,y,z, text)
	local onScreen, _x, _y = World3dToScreen2d(x, y, z)

	if onScreen then
		SetTextScale(0.19, 0.19)
		SetTextFont(0)
		SetTextProportional(1)
		-- SetTextScale(0.0, 0.55)
		SetTextColour(255, 255, 255, 255)
		SetTextDropshadow(0, 0, 0, 0, 55)
		SetTextEdge(2, 0, 0, 0, 150)
		SetTextDropShadow()
		SetTextOutline()
		SetTextEntry("STRING")
		SetTextCentre(1)
		AddTextComponentString(text)
		DrawText(_x, _y)
	end
end

function TakeHostageStart(target)
	TriggerServerEvent('takehostage:start', target)
end

function TakeHostage()
	local playerPed = PlayerPedId()
	ClearPedSecondaryTask(playerPed)
	DetachEntity(playerPed, true, false)
	local selectedWeapon = GetSelectedPedWeapon(playerPed)
	if not hostageAllowedWeapons[selectedWeapon] then
		ESX.ShowNotification("Je moet een geweer vasthebben om iemand te gijzelen!")
		return
	end

	if GetAmmoInPedWeapon(playerPed, selectedWeapon) <= 0 then
		ESX.ShowNotification("Je hebt kogels nodig in je geweer!")
		return
	end

	if not holdingHostage and not beingHeldHostage then
		local closestPlayer = GetClosestPlayer(2)
		if not IsStandingBehindPlayer(closestPlayer) then
			ESX.ShowNotification("~r~Je moet achter de persoon staan om deze persoon te gijzelen!~s~")
			return
		end
		local playerPed = GetPlayerPed(closestPlayer)
		if IsEntityDead(playerPed) then
			return
		end
		local target = GetPlayerServerId(closestPlayer)
		if closestPlayer ~= -1 and closestPlayer ~= nil then
			holdingHostage = true
			TakeHostageStart(target)
		else
			ESX.ShowNotification("Niemand is in de buurt om als gijzelaar te nemen!")
		end
	end
end

RegisterCommand("takehostage", TakeHostage)
RegisterCommand("gijzel", TakeHostage)
RegisterCommand("th", TakeHostage)

RegisterNetEvent('takehostage:killTarget', function(source)
	local playerPed = PlayerPedId()
	if not beingHeldHostage then
		return
	end
	local sourcePed = GetPlayerPed(GetPlayerFromServerId(source))

	local animationLib = 'anim@gangops@hostage@'
	local animation2 = 'victim_fail'
	local controlFlag = 0
	local length = 0.2

	LoadAnimDict(animationLib)

	--SetEntityHealth(PlayerPedId(), 0)
	DetachEntity(playerPed, true, false)
	TaskPlayAnim(playerPed, animationLib, animation2, 4.0, -4.0, length, controlFlag, 0, false, false, false)
	RemoveAnimDict(animationLib)
	SetPedCanRagdoll(playerPed, true)

	beingHeldHostage = false
	takeHostageAnimNamePlaying = nil
	takeHostageAnimDictPlaying = nil
	takeHostageControlFlagPlaying = nil
end)

RegisterNetEvent('takehostage:killMe', function(target)
	local playerPed = PlayerPedId()
	local targetPed = GetPlayerPed(GetPlayerFromServerId(target))
	ClearPedSecondaryTask(playerPed)

	local animationLib = 'anim@gangops@hostage@'
	local animation = 'perp_fail'
	local controlFlag = 48
	local length = 0.2

	LoadAnimDict(animationLib)

	TaskPlayAnim(playerPed, animationLib, animation, 4.0, -4.0, length, controlFlag, 0, false, false, false)
	local boneCoords = GetPedBoneCoords(targetPed, 0x9995)
	local coords = GetEntityCoords(playerPed)
	local selectedWeapon = GetSelectedPedWeapon(playerPed)

	ShootSingleBulletBetweenCoords(coords.x, coords.y, coords.z + 3.0, boneCoords.x, boneCoords.y, boneCoords.z, 2000, 0, selectedWeapon , playerPed, true, false, 9000.0)
	RemoveAnimDict(animationLib)
	SetPedCanRagdoll(playerPed, true)
	LocalPlayer.state:set("hostage_kill_target", true, true)
	
	holdingHostage = false
	Citizen.Wait(0)
	LocalPlayer.state:set("hostage_kill_target", false, true)

	takeHostageAnimNamePlaying = nil
	takeHostageAnimDictPlaying = nil
	takeHostageControlFlagPlaying = nil
end)

function GetPedFromBag(bag)
	if not bag then
		return
	end
	local source = bag:gsub("player:", "")
	local sourcePed = GetPlayerPed(GetPlayerFromServerId(tonumber(source)))
	return sourcePed
end

local isDuplicity = IsDuplicityVersion()
AddStateBagChangeHandler("hostage_kill_target", nil, function(bag, key, val, _, replic)
	if not val then return end
	if replic == isDuplicity then
		local sourcePed = GetPedFromBag(bag)
		SetPedShootsAtCoord(sourcePed, 0.0, 0.0, 0.0, 0)
	end
end)

RegisterNetEvent('takehostage:releaseMe', function(target)
	local playerPed = PlayerPedId()
	local targetPed = GetPlayerPed(GetPlayerFromServerId(target))
	ClearPedSecondaryTask(playerPed)

	local animationLib = 'reaction@shove'
	local animation = 'shove_var_a'
	local controlFlag = 0
	local length = 2000

	LoadAnimDict(animationLib)

	TaskPlayAnim(playerPed, animationLib, animation, 4.0, -4.0, length, controlFlag, 0, false, false, false)
	RemoveAnimDict(animationLib)
	SetPedCanRagdoll(playerPed, true)

	takeHostageAnimNamePlaying = nil
	takeHostageAnimDictPlaying = nil
	takeHostageControlFlagPlaying = nil

	Wait(900)
	ClearPedTasks(playerPed)

	holdingHostage = false
end)

RegisterNetEvent('takehostage:releaseTarget', function(source)
	local playerPed = PlayerPedId()
	ClearPedTasks(PlayerPedId())

	local animationLib = 'reaction@shove'
	local animation2 = 'shoved_back'
	local controlFlag = 0
	local length = 2000

	LoadAnimDict(animationLib)
	

	DetachEntity(PlayerPedId(), true, false)
	TaskPlayAnim(playerPed, animationLib, animation2, 3.0, -3.0, length, controlFlag, 0, false, false, false)
	RemoveAnimDict(animationLib)
	SetPedCanRagdoll(playerPed, true)

	beingHeldHostage = false
	takeHostageAnimNamePlaying = nil
	takeHostageAnimDictPlaying = nil
	takeHostageControlFlagPlaying = nil

	Citizen.Wait(900)
	ClearPedTasks(PlayerPedId())
end)

function ReleaseHostage()
	local target = hostageTarget
	if not target or target == -1 then
		return
	end

	TriggerServerEvent('takehostage:release', target)
end

function KillHostage()
	local target = hostageTarget
	if not target or target == -1 then
		return
	end

	TriggerServerEvent('takehostage:kill', target)
end