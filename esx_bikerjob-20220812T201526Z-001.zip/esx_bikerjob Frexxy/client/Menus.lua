Events = Events or {}
local PlayerPed
function OpenArmoryMenu(station)
    if Config.EnableArmoryManagement then

        local elements = {}

        if CanPutInStorage() then
            table.insert(elements, 1, {label = _U('put_object'),  value = 'put_stock'})
            table.insert(elements, 1, {label = _U('put_weapon'), value = 'put_weapon'})
        end

        if CanUseShop() then
            table.insert(elements, {label = _U('buy_object'), value = 'buy_stock'})
        end

        if CanUseStorage() then
            table.insert(elements, 1, {label = _U('get_weapon'), value = 'get_weapon'})
            table.insert(elements, 3, {label = _U('get_object'), value = 'get_stock'})
            table.insert(elements, {label = _U('buy_components'), value = 'buy_components'})
            table.insert(elements, {label = _U('buy_weapons'), value = 'buy_weapons'})
            table.insert(elements, { label = "Hernoem wapens", value = 'rename_weapons'})
        end

        ESX.UI.Menu.CloseAll()

        ESX.UI.Menu.Open(
        'default', GetCurrentResourceName(), 'armory',
        {
            title    = _U('armory'),
            align    = 'top-right',
            elements = elements,
        },
        function(data, menu)
            local result, err
            if data.current.value == 'get_weapon' then
                result, err = xpcall(OpenGetWeaponMenu, Traceback)
            elseif data.current.value == 'put_weapon' then
                result, err = xpcall(OpenPutWeaponMenu, Traceback)
            elseif data.current.value == 'rename_weapons' then
                result, err = xpcall(OpenRenameWeaponMenu, Traceback)
            elseif data.current.value == 'buy_weapons' then
                result, err = xpcall(OpenBuyWeaponsMenu, Traceback, station)
            elseif data.current.value == 'put_stock' then
                result, err = xpcall(OpenPutStocksMenu, Traceback)
            elseif data.current.value == 'get_stock' then
                result, err = xpcall(OpenGetStocksMenu, Traceback, station)
            elseif data.current.value == 'buy_stock' then
                result, err = xpcall(OpenBuyStocksMenu, Traceback)
            elseif data.current.value == 'buy_components' then
                result, err = xpcall(OpenBuyComponentsMenu, Traceback, station)
            end
            if result == false then
                print("^1ERROR: " .. tostring(err))
                ESX.ShowNotification("Er ging iets mis, probeer het opnieuw.")
            end
        end,
        function(data, menu)
            menu.close()

            CurrentAction     = 'menu_armory'
            CurrentActionMsg  = _U('open_armory')
            CurrentActionData = {station = station}
        end)
    else
        local elements = {}

        PlayerData = ESX.GetPlayerData()

        for i=1, #Stations[station].AuthorizedWeapons[JobData.grade_name], 1 do
            local weapon = Stations[station].AuthorizedWeapons[JobData.grade_name][i]
            table.insert(elements, {label = ESX.GetWeaponLabel(weapon.name), value = weapon.name})
        end

        ESX.UI.Menu.CloseAll()

        ESX.UI.Menu.Open(
        'default', GetCurrentResourceName(), 'armory',
        {
            title    = _U('armory'),
            align    = 'top-right',
            elements = elements,
        },
        function(data, menu)
            local weapon = data.current.value
            TriggerServerEvent('esx_crimejob:giveWeapon', weapon, 1)
        end,
        function(data, menu)
            menu.close()

            CurrentAction     = 'menu_armory'
            CurrentActionMsg  = _U('open_armory')
            CurrentActionData = {station = station}
        end)
    end
end

local function getVehicleLabel(model)
    local vehicleName = GetDisplayNameFromVehicleModel(model)
    local name = GetLabelText(vehicleName)
    if name ~= 'NULL' then
        return name
    end

    return vehicleName
end

function OpenVehicleSpawnerMenu(station, partNum)
    local vehicles = Stations[station].Vehicles

    ESX.UI.Menu.CloseAll()

    if Config.EnableSocietyOwnedVehicles and (Stations[station].UseSocietyVehicles == nil or Stations[station].UseSocietyVehicles) then
        local elements = {}

        TriggerServerCallback('esx_society:getVehiclesInGarage', function(garageVehicles)
            local brands = {}
            for i=1, #garageVehicles, 1 do
                if brands[garageVehicles[i].model] == nil then
                    local model = GetDisplayNameFromVehicleModel(garageVehicles[i].model)
                    if GetLabelText(model) ~= 'NULL' then
                        model = GetLabelText(model)
                    end
                    brands[garageVehicles[i].model] = { value = {} }
                    brands[garageVehicles[i].model].label = getVehicleLabel(garageVehicles[i].model)
                end
                table.insert(brands[garageVehicles[i].model].value, {label = brands[garageVehicles[i].model].label .. ' [' .. garageVehicles[i].plate .. ']', value = garageVehicles[i]})
                --table.insert(elements, {label = GetDisplayNameFromVehicleModel})
                --table.insert(elements, {label = GetDisplayNameFromVehicleModel(garageVehicles[i].model) .. ' [' .. garageVehicles[i].plate .. ']', value = garageVehicles[i]})
            end
            local elements = {}
            for k,v in pairs(brands) do
                table.insert(elements, v)
            end
            table.sort (elements, function (k1, k2) return k1.label:upper() < k2.label:upper() end )

            ESX.UI.Menu.Open(
            'default', GetCurrentResourceName(), 'brand_spawner', {
                title    = _U('vehicle_menu'),
                align    = 'top-right',
                elements = elements,
            },
            function(data2, menu2)
                ESX.UI.Menu.Open(
                'default', GetCurrentResourceName(), 'vehicle_spawner',
                {
                    title    = _U('vehicle_menu'),
                    align    = 'top-right',
                    elements = data2.current.value,
                },
                function(data, menu)
                    menu.close()

                    if IsBusy then
                        ESX.ShowNotification("~r~Een moment geduld...~s~ Probeer het over enkele seconden opnieuw!")
                        return
                    end

                    local vehicleProps = data.current.value

                    local isOnEarth, netId = table.unpack(exports['esx_jb_eden_garage2']:isCarOnEarth(vehicleProps.plate))
                    if isOnEarth then
                        exports['esx_rpchat']:printToChat("Voertuig-opslag", "Dit voertuig is nog ergens aanwezig! Gebruik ^2/getvehicle " .. vehicleProps.plate .. "^7")
                        return
                    end

                    local min, max = GetModelDimensions(vehicleProps.model)
                    local x = math.abs(min.x) + math.abs(max.x)
                    local y = math.abs(min.y) + math.abs(max.y)
                    local z = math.abs(min.z) + math.abs(max.z)
                    local maxValue = math.max(x, y, z)
                    if ESX.Game.IsSpawnPointClear(vehicles[partNum].SpawnPoint, maxValue + 1) then
                        IsBusy = true
                        ESX.Game.SpawnVehicle(vehicleProps.model, vehicles[partNum].SpawnPoint, vehicles[partNum].Heading, function(vehicle)
                            IsBusy = false
                            DecorSetInt(vehicle, 'Owned_Vehicle', 1)
                            local playerPed = PlayerPedId()
                            TaskWarpPedIntoVehicle(playerPed, vehicle, -1)

                            if vehicleProps then
                                ESX.Game.SetVehicleProperties(vehicle, vehicleProps)
                            end

                            Citizen.Wait(1000)
                            TriggerEvent('esx_jobs:spawnedVehicle', vehicle)

                            ESX.Game.SetVehicleProperties(vehicle, vehicleProps)
                        end, {
                            plate = vehicleProps.plate,
                            errCb = function()
                                IsBusy = false
                            end
                        })

                        RemoveVehicleFromGarage(vehicleProps)
                    else
                        ESX.ShowNotification("Maak aub het gebied vrij van auto's")
                    end

                end,
                function(data, menu)
                    menu.close()

                    CurrentAction     = 'menu_vehicle_spawner'
                    CurrentActionMsg  = _U('vehicle_spawner')
                    CurrentActionData = {station = station, partNum = partNum}
                end)
            end, function(data2, menu2)
                menu2.close()

                CurrentAction     = 'menu_vehicle_spawner'
                CurrentActionMsg  = _U('vehicle_spawner')
                CurrentActionData = {station = station, partNum = partNum}
            end)
        end, JobName)
    else
        local elements = {}

        for i=1, #Stations[station].AuthorizedVehicles, 1 do
            local vehicle = Stations[station].AuthorizedVehicles[i]
            table.insert(elements, {label = vehicle.label, value = vehicle.name})
        end

        ESX.UI.Menu.Open(
        'default', GetCurrentResourceName(), 'vehicle_spawner',
        {
            title    = _U('vehicle_menu'),
            align    = 'top-right',
            elements = elements,
        },
        function(data, menu)
            menu.close()

            local model = data.current.value
            local vehicle = GetClosestVehicle(vehicles[partNum].SpawnPoint.x,  vehicles[partNum].SpawnPoint.y,  vehicles[partNum].SpawnPoint.z,  3.0,  0,  71)
            if not DoesEntityExist(vehicle) then
                local playerPed = PlayerPedId()

                if Config.MaxInService == -1 then
                    print("Spawned Vehicle 1")
                    ESX.Game.SpawnVehicle(model, {
                        x = vehicles[partNum].SpawnPoint.x,
                        y = vehicles[partNum].SpawnPoint.y,
                        z = vehicles[partNum].SpawnPoint.z
                    }, vehicles[partNum].Heading, function(vehicle)
                        local result, err = pcall(function()
                            local jobPlate = exports["esx_jobs"]:getJobPlate()
                            SetVehicleNumberPlateText(vehicle, jobPlate)
                            TaskWarpPedIntoVehicle(playerPed,  vehicle,  -1)
                            Citizen.Wait(500)
                            TriggerEvent('esx_jobs:spawnedVehicle', vehicle)
                        end)
                        if not result then
                            print("^1ERROR: ^7" .. tostring(err))
                        end
                    end)
                else
                    TriggerServerCallback('esx_service:enableService', function(canTakeService, maxInService, inServiceCount)
                        if canTakeService then
                            print("Spawned Vehicle 2")
                            ESX.Game.SpawnVehicle(model, {
                                x = vehicles[partNum].SpawnPoint.x,
                                y = vehicles[partNum].SpawnPoint.y,
                                z = vehicles[partNum].SpawnPoint.z
                            }, vehicles[partNum].Heading, function(vehicle)
                                TaskWarpPedIntoVehicle(playerPed,  vehicle,  -1)
                                Citizen.Wait(500)
                                print("Spawned Vehicle 2")
                                TriggerEvent('esx_jobs:spawnedVehicle', vehicle)
                            end)
                        else
                            ESX.ShowNotification(_U('service_max') .. inServiceCount .. '/' .. maxInService)
                        end
                    end, JobName)
                end
            else
                ESX.ShowNotification(_U('vehicle_out'))
            end
        end,
        function(data, menu)
            menu.close()

            CurrentAction     = 'menu_vehicle_spawner'
            CurrentActionMsg  = _U('vehicle_spawner')
            CurrentActionData = {station = station, partNum = partNum}
        end)
    end
end

local p = promise.new()
p:resolve()
RegisterNetEvent('esx_crimejob:getArmoryWeapons')
AddEventHandler('esx_crimejob:getArmoryWeapons', function(weapons)
    p:resolve(weapons)
end)

local LastGetArmoryWeaponsData = 0
function GetArmoryWeapons()
    Citizen.Await(p)
    p = promise.new()
    LastGetArmoryWeaponsData = GetGameTimer()
    TriggerServerEvent('esx_crimejob:getArmoryWeapons')

    Citizen.SetTimeout(5000, function()
        p:resolve(false)
    end)
    return Citizen.Await(p)
end

function GetArmoryCategories(weapons)
    weapons = weapons or GetArmoryWeapons()

    if not weapons then
        print(("^1ERROR:^7 Weapons weren't received within 5 seconds! data was: %s"):format(weapons))
        ESX.ShowNotification("Er ging iets mis tijdens het laden van de wapens!")
        return
    end

    local categories = {}
    local categoryWeapons = {}
    for k,v in pairs(weapons) do
        if not categoryWeapons[v.name] then
            categoryWeapons[v.name] = {}
        end

        v.index = k
        table.insert(categoryWeapons[v.name], v)
    end

    for k,v in pairs(categoryWeapons) do
        table.insert(categories, {
            label = ("%s (%sx)"):format(ESX.GetWeaponLabel(k), #v),
            value = k
        })
    end

    return categories, categoryWeapons
end

function SelectWeapon()
    local categoryWeapons = SelectCategory()

    if not categoryWeapons then
        return 1
    end

    local p = promise.new()
    local elements = GetArmoryElements(categoryWeapons)

    ESX.UI.Menu.Open(
    'default', GetCurrentResourceName(), 'armory_get_weapon',
    {
        title    = _U('get_weapon_menu'),
        align    = 'top-right',
        elements = elements,
    },
    function(data, menu)
        p:resolve(data.current)
        menu.close()
    end,
    function(data, menu)
        menu.close()
    end,
    false,
    function(data, menu)
        p:resolve()
    end)

    return Citizen.Await(p)
end

function SelectCategory()
    local p = promise.new()
    local categories, categoryWeapons = GetArmoryCategories()

    if not categoryWeapons then
        return
    end

    ESX.UI.Menu.Open(
    'default', GetCurrentResourceName(), 'armory_select_category',
    {
        title    = _U('select_weapon_type'),
        align    = 'top-right',
        elements = categories,
    },
    function(data, menu)
        p:resolve(data.current.value)
        menu.close()
    end,
    function(data, menu)
        menu.close()
    end,
    false,
    function(data, menu)
        p:resolve()
    end)

    local category = Citizen.Await(p)

    if category then
        return categoryWeapons[category]
    end
end

function GetArmoryElements(weapons)
    weapons = weapons or GetArmoryWeapons()

    if not weapons then
        print(("^1ERROR:^7 Weapons weren't received within 5 seconds! data was: %s"):format(weapons))
        ESX.ShowNotification("Er ging iets mis tijdens het laden van de wapens!")
        return
    end
    local elements = {}

    for k,v in pairs(weapons) do
        local label
        if v.data and v.data.label then
            label = ("%s - %s"):format(ESX.GetWeaponLabel(v.name), v.data.label)
        else
            label = ESX.GetWeaponLabel(v.name)
        end
        table.insert(elements, {label = label, value = v.index or k, weaponName = v.name})
    end

    return elements
end

local LastBuyWeapon = 0
local LastGetArmoryWeapon = 0
function OpenGetWeaponMenu(skipTimer)
    if not skipTimer and GetGameTimer() - LastGetArmoryWeaponsData < 2000 then
        exports['esx_rpchat']:printToChat("RATE LIMIT", "Probeer het over enkele seconden opnieuw!", {r=255})
        ESX.ShowNotification("Probeer het over enkele seconden opnieuw!")
        return
    end

    local weapon = SelectWeapon()

    if weapon == 1 then
        return
    end

    if not weapon then
        OpenGetWeaponMenu(true)
        return
    end
    
    if not HasPedGotWeapon(PlayerPedId(), GetHashKey(weapon.value)) then
        if GetGameTimer() - LastGetArmoryWeapon < 2000 then
            exports['esx_rpchat']:printToChat("RATE LIMIT", "Probeer het over enkele seconden opnieuw!", {r=255})
            ESX.ShowNotification("Probeer het over enkele seconden opnieuw!")
            return
        end
        LastGetArmoryWeapon = GetGameTimer()
        TriggerServerCallback('esx_crimejob:removeArmoryWeapon', function()
            OpenGetWeaponMenu(true)
        end, weapon.value, weapon.weaponName)
    else
        ESX.ShowNotification('Je hebt dit wapen al.')
    end
end

function GetWeaponLabelInput()
    local p = promise.new()
    ESX.UI.Menu.Open('dialog', GetCurrentResourceName(), 'rename_weapon_label', {
        title = "Nieuwe naam"
    }, function(data, menu)
        p:resolve(data.value)
        menu.close()
    end, function(data, menu)
        p:resolve(false)
        menu.close()
    end, nil, function(data, menu)
        p:resolve()
    end)

    return Citizen.Await(p)
end

function OpenRenameWeaponMenu(skipTimer)
    if not skipTimer and GetGameTimer() - LastGetArmoryWeaponsData < 2000 then
        exports['esx_rpchat']:printToChat("RATE LIMIT", "Probeer het over enkele seconden opnieuw!", {r=255})
        ESX.ShowNotification("Probeer het over enkele seconden opnieuw!")
        return
    end

    local weapon = SelectWeapon()

    if weapon == 1 then
        return
    end

    if not weapon then
        OpenRenameWeaponMenu(true)
        return
    end

    local label = GetWeaponLabelInput()
    if label then
        if string.len(label) < 4 then
            ESX.ShowNotification("Een wapen naam moet minimaal 3 tekens lang zijn!")
            return
        end

        TriggerServerCallback('esx_crimejob:setWeaponLabel', function()
            OpenRenameWeaponMenu(true)
        end, weapon.weaponName, weapon.value, label)
    end
end

function OpenPutWeaponMenu()
    local elements   = {}
    local playerPed  = PlayerPedId()
    local weaponList = ESX.GetWeaponList()

    for i=1, #weaponList, 1 do
        local weaponHash = GetHashKey(weaponList[i].name)

        if HasPedGotWeapon(playerPed,  weaponHash,  false) and weaponList[i].name ~= 'WEAPON_UNARMED' then
            local ammo = GetAmmoInPedWeapon(playerPed, weaponHash)
            table.insert(elements, {label = weaponList[i].label, value = weaponList[i].name})
        end
    end

    ESX.UI.Menu.Open(
    'default', GetCurrentResourceName(), 'armory_put_weapon',
    {
        title    = _U('put_weapon_menu'),
        align    = 'top-right',
        elements = elements,
    },
    function(data, menu)
        menu.close()

        TriggerServerCallback('esx_crimejob:addArmoryWeapon', function()
            OpenPutWeaponMenu()
        end, data.current.value)
    end,
    function(data, menu)
        menu.close()
    end)
end

function AddComponentToElements(weapon, elements)

    local hasWeapon = HasPedGotWeapon(PlayerPed, GetHashKey(weapon.name), false)
    if not hasWeapon then
        return
    end

    table.insert(elements, {
        label = ESX.GetWeaponLabel(weapon.name),
        value = weapon.name,
        price = weapon.price,
    })
end

function OpenBuyComponentsMenu(station)
    PlayerPed = PlayerPedId()
    local elements = {}
    if Stations[station].AuthorizedWeapons[JobData.grade_name] then
        for i=1, #Stations[station].AuthorizedWeapons[JobData.grade_name], 1 do
            local weapon = Stations[station].AuthorizedWeapons[JobData.grade_name][i]
            AddComponentToElements(weapon, elements)
        end
    end

    ESX.UI.Menu.Open(
    'default', GetCurrentResourceName(), 'armory_buy_components',
    {
        title    = _U('buy_component_menu'),
        align    = 'top-right',
        elements = elements,
    },
    function(data, menu)
        if not Stations[station].AuthorizedWeapons[JobData.grade_name] then
            menu.close()
            return
        end
        for i=1, #Stations[station].AuthorizedWeapons[JobData.grade_name], 1 do
            local weapon = Stations[station].AuthorizedWeapons[JobData.grade_name][i]
            if weapon.name == data.current.value then
                menu.close()
                OpenBuyWeaponComponentsMenu(weapon, station)
                return
            end
        end
    end,
    function(data, menu)
        menu.close()
    end)
end

function GetComponentPrice(weapon, component)
    if component.price then
        return weapon.price * component.price
    end

    local data = Config.ComponentsPrices[component.name]
    if data and data.price then
        return weapon.price * data.price
    end
end


function ConfirmMenu(vehicleName, message)
	message = message or 'Type de naam van de attachement (%s) over om de attachement te verwijderen'
	local p = promise.new()
	ESX.UI.Menu.Open('dialog', GetCurrentResourceName(), 'shop_confirm', {
		title = (message):format(vehicleName)
	},
	function (confirmData, confirmMenu)
		confirmMenu.close()
		if confirmData.value and confirmData.value:lower():gsub("%W", "") == vehicleName:lower():gsub("%W", "") then
			LastTime = GetGameTimer() + 5000
			p:resolve(true)
        else
            ESX.ShowNotification("Naam ~r~niet correct~s~ overgetypt, actie geannulleerd.")
			p:resolve(false)
		end
	end, function (confirmData, confirmMenu)
        confirmMenu.close()
		p:resolve(false)
	end)

	return Citizen.Await(p)
end

local previewComponents = {}

local tintData = {
    [0] = { label = "Standaard", price = 0.0, name = "tint_0" },
    [1] = { label = "Groene", price = 0.3, name = "tint_1" },
    [2] = { label = "Goud", price = 0.6, name = "tint_2" },
    [3] = { label = "Roze", price = 0.4, name = "tint_3" },
    [4] = { label = "Leger", price = 0.4, name = "tint_4" },
    [5] = { label = "Politie", price = 0.4, name = "tint_5" },
    [6] = { label = "Oranje", price = 0.4, name = "tint_6" },
    [7] = { label = "Platinum", price = 0.6, name = "tint_7" }
}

function OpenBuyTintsMenu(weapon, station)
    local elements = {}
    local label
    local currentTint = GetPedWeaponTintIndex(PlayerPedId(), GetHashKey(weapon.name))
    local tints = weapon.tints or tintData

    SetCurrentPedWeapon(PlayerPedId(), GetHashKey(weapon.name), true)

    for i=0, GetWeaponTintCount(GetHashKey(weapon.name)) - 1 do
        local hasComponent = i == currentTint
        local componentData = tints[i]
        if componentData then
            local componentLabel = componentData.label .. " Wapentint"
            local price = GetComponentPrice(weapon, componentData)

            if hasComponent then
                label = ('%s: <span style="color:green;">%s</span>'):format(componentLabel, _U('armory_owned'))
            else
                if price > 0 then
                    label = ('%s: <span style="color:green;">%s</span>'):format(componentLabel, _U('component_price', ESX.Math.GroupDigits(price)))
                else
                    label = ('%s: <span style="color:green;">%s</span>'):format(componentLabel, _U('component_free'))
                end
            end

            elements[#elements+1] = {
                label = label,
                value = "tint_" .. i,
                price = price,
                name = "tint_" .. i,
                tintIndex = i,
                hasComponent = hasComponent,
            }
        end
    end

    ESX.UI.Menu.Open(
    'default', GetCurrentResourceName(), 'armory_buy_tints',
    {
        title    = _U('buy_tint_menu'),
        align    = 'top-right',
        elements = elements,
    },
    function(data, menu)
        if GetGameTimer() - LastBuyWeapon < 2000 then
            exports['esx_rpchat']:printToChat("RATE LIMIT", "Probeer het over enkele seconden opnieuw!", {r=255})
            ESX.ShowNotification("Probeer het over enkele seconden opnieuw!")
            return
        end
        LastBuyWeapon = GetGameTimer()
        if not data.current.hasComponent then
            local hasEnoughMoney = ServerCallback("esx_crimejob:buyWeaponComponent", data.current.price, weapon.name, data.current.name)
            if hasEnoughMoney then
                menu.close()
                ESX.ShowNotification(("Je hebt een %s gekocht voor €%s"):format(data.current.label, ESX.Math.GroupDigits(data.current.price)))
                OpenBuyWeaponComponentsMenu(weapon, station)
            else
                ESX.ShowNotification(_U('not_enough_money'))
            end
        else
            if ConfirmMenu(data.current.name) then
                ServerCallback("esx_crimejob:removeWeaponComponent", weapon.name, data.current.name)
                menu.close()
                ESX.ShowNotification(("Je hebt een %s verwijderd!"):format(data.current.name))
                OpenBuyWeaponComponentsMenu(weapon, station)
            end
        end
    end,
    function(data, menu)
        menu.close()
    end,
    function(data, menu)
        local weaponHash = GetHashKey(weapon.name)
        SetCurrentPedWeapon(PlayerPedId(), weaponHash, true)
        ESX.Game.RestoreComponents(weapon.name)
        if not data.current.hasComponent then
            SetPedWeaponTintIndex(PlayerPedId(), weaponHash, data.current.tintIndex)
        end
    end, function(data, menu)
        TriggerEvent("esx:restoreLoadout")
    end)
end

function OpenBuyWeaponComponentsMenu(weapon, station)
    local elements = {}
    local label
    SetCurrentPedWeapon(PlayerPedId(), GetHashKey(weapon.name), true)
    if weapon.components then
        for k, componentData in ipairs(weapon.components) do
            local component = ESX.GetWeaponComponent(weapon.name, componentData.name)
            if not component then
                error(("Component %s for weapon %s not found!"):format(componentData.name, weapon.name))
            end
            local hasComponent = HasPedGotWeaponComponent(PlayerPed, GetHashKey(weapon.name), component.hash)
            local price = GetComponentPrice(weapon, componentData)
    
            if hasComponent then
                label = ('%s: <span style="color:green;">%s</span>'):format(component.label, _U('armory_owned'))
            else
                if price > 0 then
                    label = ('%s: <span style="color:green;">%s</span>'):format(component.label, _U('component_price', ESX.Math.GroupDigits(price)))
                else
                    label = ('%s: <span style="color:green;">%s</span>'):format(component.label, _U('component_free'))
                end
            end
    
            elements[#elements+1] = {
                label = label,
                value = k,
                price = price,
                name = componentData.name,
                hasComponent = hasComponent,
            }
        end
    end

    table.insert(elements, {
        label = "Wapen tinten",
        value = "tints"
    })

    ESX.UI.Menu.Open(
    'default', GetCurrentResourceName(), 'armory_buy_components',
    {
        title    = _U('buy_component_menu'),
        align    = 'top-right',
        elements = elements,
    },
    function(data, menu)
        if GetGameTimer() - LastBuyWeapon < 2000 then
            exports['esx_rpchat']:printToChat("RATE LIMIT", "Probeer het over enkele seconden opnieuw!", {r=255})
            ESX.ShowNotification("Probeer het over enkele seconden opnieuw!")
            return
        end

        if data.current.value == "tints" then
            OpenBuyTintsMenu(weapon, station)
            return
        end

        LastBuyWeapon = GetGameTimer()
        if not data.current.hasComponent then
            local hasEnoughMoney = ServerCallback("esx_crimejob:buyWeaponComponent", data.current.price, weapon.name, data.current.name)
            if hasEnoughMoney then
                menu.close()
                ESX.ShowNotification(("Je hebt een %s gekocht voor €%s"):format(data.current.label, ESX.Math.GroupDigits(data.current.price)))
                OpenBuyWeaponComponentsMenu(weapon, station)
            else
                ESX.ShowNotification(_U('not_enough_money'))
            end
        else
            if ConfirmMenu(data.current.name) then
                ServerCallback("esx_crimejob:removeWeaponComponent", weapon.name, data.current.name)
                menu.close()
                ESX.ShowNotification(("Je hebt een %s verwijderd!"):format(data.current.name))
                OpenBuyWeaponComponentsMenu(weapon, station)
            end
        end
    end,
    function(data, menu)
        menu.close()
    end,
    function(data, menu)
        local weaponHash = GetHashKey(weapon.name)
        for i=1, #previewComponents do
            RemoveWeaponComponentFromPed(PlayerPedId(), weaponHash, previewComponents[i])
        end
        SetCurrentPedWeapon(PlayerPedId(), weaponHash, true)
        ESX.Game.RestoreComponents(weapon.name)
        previewComponents = {}
        if not data.current.hasComponent then
            local componentData = weapon.components[data.current.value]
            if componentData then
                local component = ESX.GetWeaponComponent(weapon.name, componentData.name)
                local attachementModel = component.hash
                GiveWeaponComponentToPed(PlayerPedId(), weaponHash, attachementModel)
                previewComponents[#previewComponents + 1] = attachementModel
            end
        end
    end, function(data, menu)
        TriggerEvent("esx:restoreLoadout")
    end)
end

local function getLimitKey(weapon)
    local weaponData = Weapons[weapon]
    if weaponData and weaponData.category then
        if Limits[weaponData.category] then
            return weaponData.category
        end
    end

    return weapon
end

function GetWeaponLeftData()
    return ServerCallback("esx_crimejob:getWeaponLeftData")
end

function OpenBuyWeaponsMenu(station)
    local weapons = GetArmoryWeapons()
    if not weapons then
        ESX.ShowNotification("~r~Er ging iets mis tijdens het laden van de wapens, probeer het over enkele seconden opnieuw!")
        return
    end
    local elements = {}

    PlayerData = ESX.GetPlayerData()

    if not Stations[station].AuthorizedWeapons[JobData.grade_name] then
        ESX.ShowNotification("Je mag geen wapens kopen!")
        return
    end

    local weaponLeftData = GetWeaponLeftData()

    for i=1, #Stations[station].AuthorizedWeapons[JobData.grade_name], 1 do
        local weapon = Stations[station].AuthorizedWeapons[JobData.grade_name][i]
        local count  = 0

        for i=1, #weapons, 1 do
            if weapons[i].name == weapon.name then
                count = count + 1
            end
        end

        local category = getLimitKey(weapon.name)
        local numBought = GetNumBought(weaponLeftData, category)
        if not numBought then
            print(("numBought is nil for %s"):format(category))
        end
        local price = GetPrice(category, weapon.price, numBought)
        table.insert(elements, {
            label = ESX.GetWeaponLabel(weapon.name) .. ' - €' .. ESX.Math.GroupDigits(price),
            value = weapon.name,
            price = price,
            numBought = numBought,
            count = count
        })
    end

    ESX.UI.Menu.Open(
    'default', GetCurrentResourceName(), 'armory_buy_weapons',
    {
        title    = _U('buy_weapon_menu'),
        align    = 'top-right',
        elements = elements,
    },
    function(data, menu)
        local elements = {
            { label = "Koop - €" .. ESX.Math.GroupDigits(data.current.price), value = 'buy' },
            { label = "In opslag - " .. (data.current.count or "Onbekend") },
            { label = "Ingekocht deze lading - " .. (data.current.numBought or "Onbekend") }
        }
        ESX.UI.Menu.Open(
            'default',
            GetCurrentResourceName(),
            'armory_buy_weapon',
            {
                title = "Armory - " .. ESX.GetWeaponLabel(data.current.value),
                align = 'top-right',
                elements = elements
            }, function (data2, menu2)
                if data2.current.value == 'buy' then
                    if GetGameTimer() - LastBuyWeapon < 2000 then
                        exports['esx_rpchat']:printToChat("RATE LIMIT", "Probeer het over enkele seconden opnieuw!", {r=255})
                        ESX.ShowNotification("Probeer het over enkele seconden opnieuw!")
                        return
                    end
                    LastBuyWeapon = GetGameTimer() + 10000
                    local _, hasEnoughMoney = xpcall(function()
                        return ServerCallback('esx_crimejob:buyWeapon', data.current.value)
                    end, function()
                        ESX.ShowNotification("Er ging iets mis tijdens het kopen van het wapen (waarschijnlijk internet problemen/server die even vastloopt)")
                    end)
                    LastBuyWeapon = GetGameTimer()
                    if hasEnoughMoney == nil then
                        return
                    end
                    if hasEnoughMoney then
                        ESX.ShowNotification(("Je hebt een %s gekocht voor €%s"):format(ESX.GetWeaponLabel(data.current.value), ESX.Math.GroupDigits(data.current.price)))
                        menu2.close()
                        menu.close()
                        OpenBuyWeaponsMenu(station)
                    else
                        ESX.ShowNotification(_U('not_enough_money'))
                    end
                end
            end,
            function(data2, menu2)
                menu2.close()
            end
        )
    end,
    function(data, menu)
        menu.close()
    end)
end

local lastBuyItem = 0
function Events.BuyItem(itemName)
    if GetGameTimer() - lastBuyItem < 1000 then
        ESX.ShowNotification("Probeer het over enkele seconden opnieuw!")
        return
    end

    lastBuyItem = GetGameTimer()
    TriggerServerEvent('esx_crimejob:buyItem', itemName)
end

function OpenBuyStocksMenu()
    ESX.UI.Menu.CloseAll()

    local elements = {}
    for k,v in pairs(Config.Items) do
        table.insert(elements, {value = k, label = ("%s - €%i"):format(v.label, v.price)})
    end

	ESX.UI.Menu.Open('default', GetCurrentResourceName(), 'buy_item_menu', {
		title    = _U('biker_buy_items'),
		align    = 'top-right',
        elements = elements
    }, function(data, menu)
        Events.BuyItem(data.current.value)
	end, function(data, menu)
		menu.close()
	end)
end

local getStockItemsPromise = promise.new()
RegisterNetEvent('esx_crimejob:getStockItems')
AddEventHandler('esx_crimejob:getStockItems', function(items)
    getStockItemsPromise:resolve(items)
end)

local LastGetStockData = 0
function GetStockItems()
    getStockItemsPromise = promise.new()
    Citizen.SetTimeout(10000, function()
        getStockItemsPromise:resolve('timeout')
    end)
    LastGetStockData = GetGameTimer()
    TriggerServerEvent('esx_crimejob:getStocksItems')

    local items = Citizen.Await(getStockItemsPromise)
    if items == 'timeout' then
        exports['esx_rpchat']:printToChat("OPSLAG", "Er ging iets mis tijdens het ophalen van de opslag, probeer het later opnieuw!")
        ESX.ShowNotification("Er ging iets mis tijdens het ophalen van de data!")
        return nil
    end
    return items
end

function IsBlacklistedItem(station, itemName)
    local station = Stations[station]
    if not station or not station.BlacklistedItems or not station.BlacklistedItems[JobData.grade_name] then
        return false
    end

    return station.BlacklistedItems[JobData.grade_name][itemName] or false
end

local LastGetStock = 0
function Events.GetStockItem(itemName, count)
    if GetGameTimer() - LastGetStock < 1000 then
        exports['esx_rpchat']:printToChat("RATE LIMIT", "Probeer het over enkele seconden opnieuw!", {r=255})
        ESX.ShowNotification("Probeer het over enkele seconden opnieuw!")
        return
    end

    LastGetStock = GetGameTimer()
    ServerCallback("esx_crimejob:getStockItem", itemName, count)
end

function OpenGetStocksMenu(station, skipTimer)
    if not skipTimer and GetGameTimer() - LastGetStockData < 1000 then
        exports['esx_rpchat']:printToChat("RATE LIMIT", "Probeer het over enkele seconden opnieuw!", {r=255})
        ESX.ShowNotification("Probeer het over enkele seconden opnieuw!")
        return
    end
    local items = GetStockItems()
    if not items then
        return
    end
    local elements = {}

    for k,v in pairs(items) do
        if v.count > 0 and not IsBlacklistedItem(station, v.name) then
            if v.name == 'black_money' or v.name == 'money' then
                table.insert(elements, {label = ('<span style="color:green;">€%s</span> %s'):format(v.count, v.label), value = v})
            else
                table.insert(elements, {label = 'x' .. v.count .. ' ' .. v.label, value = v})
            end
        end
    end
    xpcall(function()
        table.sort(elements, function(a, b)
            if not a.value or not a.value.name then
                return false
            end
            if not b.value or not b.value.name then
                return true
            end
            local aLabel = a.value.label or a.value.name
            local bLabel = b.value.label or b.value.name
            return aLabel:upper() < bLabel:upper()
        end)
    end, Traceback or debug.traceback)

    ESX.UI.Menu.Open(
    'default', GetCurrentResourceName(), 'get_stocks_menu',
    {
        title    = _U('biker_stock'),
        align    = 'top-right',
        elements = elements
    },
    function(data, menu)
        local itemName = data.current.value.name

        ESX.UI.Menu.Open(
        'dialog', GetCurrentResourceName(), 'stocks_menu_get_item_count',
        {
            title = _U('quantity'),
        },
        function(data2, menu2)
            local count = tonumber(data2.value)
            if count == nil then
                ESX.ShowNotification(_U('quantity_invalid'))
            else
                menu2.close()
                menu.close()

                Events.GetStockItem(itemName, count)

                OpenGetStocksMenu(true)
            end
        end,
        function(data2, menu2)
            menu2.close()
        end)
    end,
    function(data, menu)
        menu.close()
    end)
end

function GetPlayerInventory()
    return ServerCallback('esx_crimejob:getPlayerInventory')
end

function OpenPutStocksMenu()
    local inventory = GetPlayerInventory()
    local elements = {}

    for k,item in pairs(inventory.items) do
        if item.count > 0 then
            table.insert(elements, {label = item.label .. ' x' .. item.count, type = 'item_standard', value = item})
        end
    end
    
    table.insert(elements, {label = ('%s <span style="color:green;">€%s</span>'):format(inventory.blackMoney.label, inventory.blackMoney.money), type = 'item_standard', value = inventory.blackMoney})
    table.insert(elements, {label = ('%s <span style="color:green;">€%s</span>'):format(inventory.money.label, inventory.money.money), type = 'item_standard', value = inventory.money})

    ESX.UI.Menu.Open(
    'default', GetCurrentResourceName(), 'put_stocks_menu',
    {
        title    = _U('inventory'),
        elements = elements,
        align   = 'top-right'
    },
    function(data, menu)
        local item = data.current.value
        local itemName = item.name

        ESX.UI.Menu.Open(
        'dialog', GetCurrentResourceName(), 'stocks_menu_put_item_count',
        {
            title = _U('quantity')
        },
        function(data2, menu2)
            local count = tonumber(data2.value)
            local itemCount = item.count or item.money
            if count == nil or count > itemCount then
                ESX.ShowNotification(_U('quantity_invalid'))
            else
                TriggerServerEvent('esx_crimejob:putStockItems', itemName, count)
                Citizen.Wait(100)
                menu2.close()
                menu.close()

                OpenPutStocksMenu()
            end
        end,
        function(data2, menu2)
            menu2.close()
        end)
    end,
    function(data, menu)
        menu.close()
    end)
end