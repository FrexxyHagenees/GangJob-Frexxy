Config                            = {}
Config.DrawDistance               = 20.0
Config.MarkerType                 = 1
Config.MarkerSize                 = { x = 1.5, y = 1.5, z = 1.0 }
Config.MarkerColor                = { r = 50, g = 50, b = 204 }

Config.HandcuffTimer              = 30 * 60000 -- 10 mins

Config.VehicleLimit               = 43

--- The time after uncuffing someone to be able to cuff him again without using a handcuff item
Config.HandcuffTimeout = 120

Config.EnablePlayerManagement     = true
Config.EnableArmoryManagement     = true
Config.EnableESXIdentity          = true -- only turn this on if you are using esx_identity
Config.EnableNonFreemodePeds      = false -- turn this on if you want custom peds
Config.EnableSocietyOwnedVehicles = true
Config.EnableLicenses             = false
Config.MaxInService               = -1
Config.Locale                     = 'en'
Config.Jobs = {
    biker = { society = 'society_biker', label = 'DTMC', name = 'biker', criminal = true },
    mafia = { society = 'society_mafia', label = '14K', name = 'mafia', criminal = true },
    cartel = { society = 'society_cartel', label = 'Cartel', name = 'cartel', criminal = true },
    gang = { society = 'society_gang', label = 'Shqiptar', name = 'gang', criminal = true },
    narcos = { society = 'society_narcos', label = 'Narcos', name = 'narcos', criminal = true },
    bratva = { society = 'society_bratva', label = 'Cartel del Lago', name = 'bratva', criminal = true },
    peaky = { society = 'society_peaky', label = 'Peaky Blinders', name = 'peaky', criminal = true },
    reporter = { society = 'society_reporter', label = 'Reporter', name = 'reporter', phone = 'reporter', criminal = false },
    media = { society = 'society_media', label = 'TDA Media', name = 'media', phone = 'media', criminal = false },
    justitie = { society = 'society_justitie', label = 'justitie', name = 'justitie', phone = 'justitie', criminal = false },
    lcardealer = { society = 'society_lcardealer', label = 'lcardealer', name = 'lcardealer', criminal = false },
}

Config.Items = {
    blowpipe = { price = 5000, label = 'Snijbrander' },
    ammopistol = { price = 10000, label = '.45 ACP Munitie (Pistool)' },
    ammopistolhp = { price = 20000, label = '.45 ACP Hollowpoint Munitie (Pistool)' },
    ammopistolfmj = { price = 20000, label = '.45 ACP Full Metal Jacket (Pistool)' },
	ammosmg = { price = 20000, label = '9x18mm Munitie (SMG)' },
	ammorifle = { price = 20000, label = '5.45x39mm Munitie (AK)' },
	ammoriflefmj = { price = 20000, label = '5.45x39mm Full Metal Jacket (AK)' },
	ammosniper = { price = 15000, label = '7.62x54R Munitie (Sniper)' },
    ammoshotgun = { price = 10000, label = '12-gauge Munitie' },
    handcuff = { price = 500, label = 'Handboeien' }
}

local tints = {
    [0] = { label = "Standaard", price = 0.0, name = "tint_0" },
    [1] = { label = "Groene", price = 0.3, name = "tint_1" },
    [2] = { label = "Goud", price = 0.6, name = "tint_2" },
    [3] = { label = "Roze", price = 0.4, name = "tint_3" },
    [4] = { label = "Leger", price = 0.4, name = "tint_4" },
    [5] = { label = "Politie", price = 0.4, name = "tint_5" },
    [6] = { label = "Oranje", price = 0.4, name = "tint_6" },
    [7] = { label = "Platinum", price = 0.6, name = "tint_7" }
}

local tintsMk2 = {
    [0] = { label = "Classic Black", price = 0.3, name = "tint_0" },
    [1] = { label = "Classic Gray", price = 0.3, name = "tint_1" },
    [2] = { label = "Classic Two Tone", price = 0.3, name = "tint_2" },
    [3] = { label = "Classic White", price = 0.3, name = "tint_3" },
    [4] = { label = "Classic Beige", price = 0.3, name = "tint_4" },
    [5] = { label = "Classic Green", price = 0.3, name = "tint_5" },
    [6] = { label = "Classic Blue", price = 0.3, name = "tint_6" },
    [7] = { label = "Classic Earth", price = 0.3, name = "tint_7" },
    [8] = { label = "Classic Brown & Black", price = 0.3, name = "tint_8" },
    [9] = { label = "Red Contrast", price = 0.3, name = "tint_9" },
    [10] = { label = "Blue Contrast", price = 0.3, name = "tint_10" },
    [11] = { label = "Yellow Contrast", price = 0.3, name = "tint_11" },
    [12] = { label = "Orange Contrast", price = 0.3, name = "tint_12" },
    [13] = { label = "Bold Pink", price = 0.3, name = "tint_13" },
    [14] = { label = "Bold Purple & Yellow", price = 0.3, name = "tint_14" },
    [15] = { label = "Bold Orange", price = 0.3, name = "tint_15" },
    [16] = { label = "Bold Green & Purple", price = 0.3, name = "tint_16" },
    [17] = { label = "Bold Red Features", price = 0.3, name = "tint_17" },
    [18] = { label = "Bold Green Features", price = 0.3, name = "tint_18" },
    [19] = { label = "Bold Cyan Features", price = 0.3, name = "tint_19" },
    [20] = { label = "Bold Yellow Features", price = 0.3, name = "tint_20" },
    [21] = { label = "Bold Red & White", price = 0.3, name = "tint_21" },
    [22] = { label = "Bold Blue & White", price = 0.3, name = "tint_22" },
    [23] = { label = "Metallic Gold", price = 0.3, name = "tint_23" },
    [24] = { label = "Metallic Platinum", price = 0.3, name = "tint_24" },
    [25] = { label = "Metallic Gray & Lilac", price = 0.3, name = "tint_25" },
    [26] = { label = "Metallic Purple & Lime", price = 0.3, name = "tint_26" },
    [27] = { label = "Metallic Red", price = 0.3, name = "tint_27" },
    [28] = { label = "Metallic Green", price = 0.3, name = "tint_28" },
    [29] = { label = "Metallic Blue", price = 0.3, name = "tint_29" },
    [30] = { label = "Metallic White & Aqua", price = 0.3, name = "tint_30" },
    [31] = { label = "Metallic Red & Yellow", price = 0.3, name = "tint_31" }
}

Config.ComponentsPrices = {
    ['clip_extended'] = { price = 0.25 },
    ['clip_drum'] = { price = 0.5 },
    ['flashlight'] = { price = 0.05 },
    ['suppressor'] = { price = 0.5 },
    ['luxary_finish'] = { price = 0.5 },
    ['grip'] = { price = 0.1 },
    ['scope'] = { price = 0.3 },
    ['scope_holo'] = { price = 0.3 },
    ['scope_medium'] = { price = 0.3 },
    ['clip_default'] = { price = 0 },
    ['clip_hp'] = { price = 0.3 },
    ['clip_fmj'] = { price = 0.3 },
    ['brake_1'] = { price = 0.1 },
    ['brake_2'] = { price = 0.1 },
    ['brake_3'] = { price = 0.1 },
    ['brake_4'] = { price = 0.1 },
    ['brake_5'] = { price = 0.1 },
    ['brake_6'] = { price = 0.1 },
    ['brake_7'] = { price = 0.1 },
    ['barrel_default'] = { price = 0 },
    ['barrel_heavy'] = { price = 0.5 },
}

local clipDefault = { name = 'clip_default', price = 0 }
local components = {
    pistol = {
        clipDefault,
        { name = 'clip_extended' },
        { name = 'clip_hp' },
        { name = 'clip_fmj' },
        { name = 'flashlight' },
        { name = 'suppressor' },
        { name = 'luxary_finish' }
    },
    pistol_mk2 = {
        clipDefault,
        { name = 'clip_extended' },
        { name = 'clip_hp' },
        { name = 'clip_fmj' },
        { name = 'flashlight' },
        { name = 'suppressor' },
        { name = 'brake_1' },
        { name = 'scope' },
    },
    assaultRifle = {
        clipDefault,
        { name = 'clip_extended' },
        { name = 'clip_drum' },
        { name = 'flashlight' },
        { name = 'scope' },
        { name = 'suppressor' },
        { name = 'grip' },
        { name = 'luxary_finish' }
    },
    assaultRifleMk2 = {
        clipDefault,
        { name = 'clip_extended' },
        { name = 'flashlight' },
        { name = 'scope_holo', price = 0.0 },
        { name = 'scope', price = 0.0 },
        { name = 'scope_medium' },
        { name = 'brake_1' },
        { name = 'brake_2' },
        { name = 'brake_3' },
        { name = 'brake_4' },
        { name = 'brake_5' },
        { name = 'brake_6' },
        { name = 'brake_7' },
        { name = 'suppressor' },
        { name = 'grip' },
        { name = 'barrel_default' },
        { name = 'barrel_heavy' },
    },
    compactRifle = {
        clipDefault,
        { name = 'clip_extended' }
    },
    miniSmg = {
        clipDefault,
        { name = 'clip_extended' }
    }
}

Limits = {
    WEAPON_BAT = { maxPerWeek = 40 },
    WEAPON_KNIFE = { maxPerWeek = 40 },
    WEAPON_SWITCHBLADE = { maxPerWeek = 40 },
    WEAPON_MACHETE = { maxPerWeek = 30 },
    WEAPON_PISTOL = { maxPerWeek = 20, exponent = 1.9, modifier = 2 },
    WEAPON_PISTOL_MK2 = { maxPerWeek = 20, exponent = 1.9, modifier = 2 },
    WEAPON_ASSAULTRIFLE = { maxPerWeek = 10, exponent = 2.1, modifier = 0, divider = 2 },
    WEAPON_ASSAULTRIFLE_MK2 = { maxPerWeek = 10, exponent = 2.5, modifier = 0, divider = 2 },
    WEAPON_COMPACTRIFLE = { maxPerWeek = 10 },
    WEAPON_SAWNOFFSHOTGUN = { maxPerWeek = 20 },
    WEAPON_MINISMG = { maxPerWeek = 10 },
    pistols = { maxPerWeek = 20 }
}

Weapons = {
    WEAPON_BAT =            { name = 'WEAPON_BAT',            price =  12500, maxPerWeek = 4 },
    WEAPON_KNIFE =          { name = 'WEAPON_KNIFE',          price =  11250, maxPerWeek = 4 },
    WEAPON_SWITCHBLADE =    { name = 'WEAPON_SWITCHBLADE',    price =  11250, maxPerWeek = 4 },
    WEAPON_MACHETE =        { name = 'WEAPON_MACHETE',        price =  17500, maxPerWeek = 3 },
    WEAPON_PISTOL =         { name = 'WEAPON_PISTOL',         price =  70000, maxPerWeek = 2,  components = components.pistol },
    WEAPON_PISTOL_MK2 =     { name = 'WEAPON_PISTOL_MK2',     price = 100000, maxPerWeek = 2, components = components.pistol_mk2, tints = tintsMk2 },
    WEAPON_ASSAULTRIFLE =   { name = 'WEAPON_ASSAULTRIFLE',   price = 200000, maxPerWeek = 10, components = components.assaultRifle },
    WEAPON_ASSAULTRIFLE_MK2 ={ name = 'WEAPON_ASSAULTRIFLE_MK2',   price = 250000, maxPerWeek = 10, components = components.assaultRifleMk2, tints = tintsMk2 },
    WEAPON_COMPACTRIFLE =   { name = 'WEAPON_COMPACTRIFLE',   price = 150000, maxPerWeek = 10, components = components.compactRifle },
    WEAPON_SAWNOFFSHOTGUN = { name = 'WEAPON_SAWNOFFSHOTGUN', price =  90000, maxPerWeek = 2 },
    WEAPON_STONE_HATCHET =  { name = 'WEAPON_STONE_HATCHET',  price =  11250, maxPerWeek = 0, category = 'WEAPON_KNIFE' },
    WEAPON_MINISMG =        { name = 'WEAPON_MINISMG',        price = 120000, maxPerWeek = 1, components = components.miniSmg },
}

Config.Stations = {
    biker = {
        [1] = {
            HasJobMenu = true,
            HasPhoneNumber = false,
            HasMoneyLaundering = true,
            CanConfiscate = true,
            Blip = {
                Pos     = { x = 105.17, y = 326.25, z = 112.10 },
                Sprite  = 226,
                Display = 4,
                Scale   = 1.4,
                Colour  = 46
            },

            AuthorizedWeapons = {
                fullpatch = {},
                roadcaptain = {},
                enforcer = {},
                treasurer = {
                    Weapons.WEAPON_BAT,
                    Weapons.WEAPON_KNIFE,
                    Weapons.WEAPON_SWITCHBLADE,
                    Weapons.WEAPON_MACHETE,
                    Weapons.WEAPON_PISTOL,
                    Weapons.WEAPON_PISTOL_MK2,
                    Weapons.WEAPON_MINISMG,
                    Weapons.WEAPON_COMPACTRIFLE,
                    Weapons.WEAPON_ASSAULTRIFLE,
                    Weapons.WEAPON_ASSAULTRIFLE_MK2,
                    Weapons.WEAPON_SAWNOFFSHOTGUN,
                },
                secretary = {},
                sergeant = {
                    Weapons.WEAPON_BAT,
                    Weapons.WEAPON_KNIFE,
                    Weapons.WEAPON_SWITCHBLADE,
                    Weapons.WEAPON_MACHETE,
                    Weapons.WEAPON_PISTOL,
                    Weapons.WEAPON_PISTOL_MK2,
                    Weapons.WEAPON_MINISMG,
                    Weapons.WEAPON_COMPACTRIFLE,
                    Weapons.WEAPON_ASSAULTRIFLE,
                    Weapons.WEAPON_ASSAULTRIFLE_MK2,
                    Weapons.WEAPON_SAWNOFFSHOTGUN,
                },
                 vpresident = {
                    Weapons.WEAPON_BAT,
                    Weapons.WEAPON_KNIFE,
                    Weapons.WEAPON_SWITCHBLADE,
                    Weapons.WEAPON_MACHETE,
                    Weapons.WEAPON_PISTOL,
                    Weapons.WEAPON_PISTOL_MK2,
                    Weapons.WEAPON_MINISMG,
                    Weapons.WEAPON_COMPACTRIFLE,
                    Weapons.WEAPON_ASSAULTRIFLE,
                    Weapons.WEAPON_ASSAULTRIFLE_MK2,
                    Weapons.WEAPON_SAWNOFFSHOTGUN,
                },
                boss = {
                    Weapons.WEAPON_BAT,
                    Weapons.WEAPON_KNIFE,
                    Weapons.WEAPON_SWITCHBLADE,
                    Weapons.WEAPON_MACHETE,
                    Weapons.WEAPON_PISTOL,
                    Weapons.WEAPON_PISTOL_MK2,
                    Weapons.WEAPON_MINISMG,
                    Weapons.WEAPON_COMPACTRIFLE,
                    Weapons.WEAPON_ASSAULTRIFLE,
                    Weapons.WEAPON_ASSAULTRIFLE_MK2,
                    Weapons.WEAPON_SAWNOFFSHOTGUN,
                    Weapons.WEAPON_STONE_HATCHET,
                },
                national_president = {
                    Weapons.WEAPON_BAT,
                    Weapons.WEAPON_KNIFE,
                    Weapons.WEAPON_SWITCHBLADE,
                    Weapons.WEAPON_MACHETE,
                    Weapons.WEAPON_PISTOL,
                    Weapons.WEAPON_PISTOL_MK2,
                    Weapons.WEAPON_MINISMG,
                    Weapons.WEAPON_COMPACTRIFLE,
                    Weapons.WEAPON_ASSAULTRIFLE,
                    Weapons.WEAPON_ASSAULTRIFLE_MK2,
                    Weapons.WEAPON_SAWNOFFSHOTGUN,
                    Weapons.WEAPON_STONE_HATCHET,
                },
            },

            AuthorizedVehicles = {
                { name = 'gburrito2',  label = 'Busje', price = 1000 },
                { name = 'avarus',    label = 'Motor Avarus', price = 10000 },
                { name = 'sanctus',   label = 'Motor Sanctus', price = 10000 },
                { name = '4x4',      label = '4x4', price = 100000 },
                { name = 'rrphantom',      label = 'Patrov baas', price = 5000000},
            },

            Armories = {
                --vector3(978.38, 50.03, 115.17), --[[Casino]]
                --vector3(-1044.36, -236.78, 36.96) --[[LifeInvader]]
                --vector3(-1633.46, -2997.34, -79.14) --[[NightClub]]
                vector3(142.38, 332.05, 110.89) --[[DTMC]]
            },

            Vehicles = {
                {
                    --Spawner    = vector3(927.74, 52.97, 80.10), --[[Casino]]
                    --Spawner = vector3(-1094.79, -261.50, 36.68), --[[LifeInvader]]
                    --SpawnPoint = vector3(917.61, 50.64, 79.90), --[[Casino]]
                    --SpawnPoint = vector3(-1099.31, -264.81, 36.68), --[[LifeInvader]]
                    --Heading    = 332.26, --[[Casino]]
                    --SpawnPoint = vector3(209.21, -3122.08, 4.79), --[[NightClub]]
                    --Spawner = vector3(204.71, -3132.58, 4.79), --[[NightClub]]
                    --Heading = 86.82
                    SpawnPoint = vector3(137.90, 311.45, 111.14), --[[DTMC]]
                    Spawner = vector3(131.25, 319.41, 111.14), --[[DTMC]]
                    Heading = 88.46
                }
            },

            Helicopters = {
                {   
                    Spawner = vector3(114.57, 277.24, 108.97), --[[DTMC]]
                    SpawnPoint = vector3(113.62, 293.97, 108.97), --[[DTMC]]
                    Heading = 66.68 --[[DTMC]]
                    --Spawner = vector3(206.05, -3185.56, 39.60), --[[LifeInvader]]
                    --SpawnPoint = vector3(231.26, -3188.32, 39.80), --[[LifeInvader]]
                    --Heading = 86.82 --[[LifeInvader]]
                    --Spawner = vector3(-1062.42, -243.79, 53.01), --[[LifeInvader]]
                    --SpawnPoint = vector3(-1049.31, -234.87, 52.51), --[[LifeInvader]]
                    --Heading = 118.51 --[[LifeInvader]]
                    --Spawner    = vector3(963.92, 59.07, 111.61), --[[Casino]]
                    --SpawnPoint = vector3(966.64, 42.26, 122.13), --[[Casino]]
                    --Heading    = 94.05, --[[Casino]]
                },
                {
                    -- sandy
                    Spawner = vector3(1384.16, 3006.80, 39.83),
                    SpawnPoint = vector3(1402.38, 3000.50, 40.55),
                    Heading = 316 
                }
            },

            VehicleDeleters = {
                --vector3(203.87, -3121.04, 4.23) --[[NightClub]]
                --vector3(-1100.00, -263.11, 36.72) --[[LifeInvader]]
                --vector3(935.07, -0.62, 77.76), --[[ Casino ]]
                --vector3(917.61, 50.64, 79.90), --[[ Casino ]]
                vector3(109.48, 316.19, 111.12), --[[DTMC]]
                vector3(113.62, 293.97, 108.97) --[[DTMC]]
            },

            BossActions = {
                --vector3(-1617.71, -3013.12, -76.21) --[[LifeInvader]]
                --vector3(1110.32, 241.84, -46.83) --[[ Casino ]]
                --vector3(-1054.18, -233.28, 43.02) --[[LifeInvader]]
                vector3(141.11, 340.20, 115.62) --[[DTMC]]
            },
        }
    },

    mafia = {
        {
            HasJobMenu = true,
            HasPhoneNumber = false,
            HasMoneyLaundering = true,
            CanConfiscate = true,
            Blip = {
                Pos     = { x = 939.26, y = -1478.66, z = 30.10 },
                Sprite  = 378,
                Display = 4,
                Scale   = 1.4,
                Colour  = 76,
            },

            AuthorizedWeapons = {
                soldato = {},
                capo = {},
                consigliere = {},
                stric = {
                    Weapons.WEAPON_BAT,
                    Weapons.WEAPON_KNIFE,
                    Weapons.WEAPON_SWITCHBLADE,
                    Weapons.WEAPON_MACHETE,
                    Weapons.WEAPON_PISTOL,
                    Weapons.WEAPON_PISTOL_MK2,
                    Weapons.WEAPON_MINISMG,
                    Weapons.WEAPON_COMPACTRIFLE,
                    Weapons.WEAPON_ASSAULTRIFLE,
                    Weapons.WEAPON_ASSAULTRIFLE_MK2,
                    Weapons.WEAPON_SAWNOFFSHOTGUN,
                },
                boss = {
                    Weapons.WEAPON_BAT,
                    Weapons.WEAPON_KNIFE,
                    Weapons.WEAPON_SWITCHBLADE,
                    Weapons.WEAPON_MACHETE,
                    Weapons.WEAPON_PISTOL,
                    Weapons.WEAPON_PISTOL_MK2,
                    Weapons.WEAPON_MINISMG,
                    Weapons.WEAPON_COMPACTRIFLE,
                    Weapons.WEAPON_ASSAULTRIFLE,
                    Weapons.WEAPON_ASSAULTRIFLE_MK2,
                    Weapons.WEAPON_SAWNOFFSHOTGUN,
                },
                advocaat = {},
            },

            AuthorizedVehicles = {
                { name = 'schafter3',  label = 'Véhicule Civil' },
                { name = 'btype',      label = 'Roosevelt' },
                { name = 'sandking',   label = '4X4' },
                { name = 'mule3',      label = 'Camion de Transport' },
                { name = 'guardian',   label = 'Grand 4x4' },
                { name = 'burrito',   label = 'Fourgonnette' },
                { name = 'mesa',       label = 'Tout-Terrain' },
                { name = 's63w222',   label = 'Mercedes S63 AMG'}
            },

            Cloakrooms = {
                vector3(932.89, -1462.19, 32.61),
            },

            Armories = {
                vector3(952.41, -1467.09, 30.02),
            },

            Vehicles = {
                {
                    Spawner    = vector3(933.58, -1510.52, 29.79),
                    SpawnPoint = vector3(940.81, -1500.57, 29.25),
                    Heading    = 280.58,
                }
            },

            Helicopters = {
                {
                    Spawner    = vector3(953.04, -1470.91, 37.15),
                    SpawnPoint = vector3(954.99, -1464.07, 37.35),
                    Heading    = 271.31,
                },
                {
                    -- sandy
                    Spawner = vector3(1384.16, 3006.80, 39.83),
                    SpawnPoint = vector3(1402.38, 3000.50, 40.55),
                    Heading = 316 
                }
            },

            VehicleDeleters = {
                vector3(939.45, -1476.35, 29.10),
                vector3(956.75, -1464.04, 37.35),
                vector3(1398.15, 2996.79, 39.55),
            },

            BossActions = {
                vector3(958.95, -1476.03, 30.02)
            },
        }
    },

    cartel = {
        {
            HasJobMenu = true,
            HasPhoneNumber = false,
            HasMoneyLaundering = true,
            CanConfiscate = true,
            Blip = {
                Pos     = { x = 1456.54, y =1114.98, z = 114.33 },
                Sprite  = -1,
                Display = 4,
                Scale   = 1.2,
                Colour  = 29,
                Name = "La Icona"
            },

            AuthorizedWeapons = {
                associate = {},
                soldato = {},
                capo = {},
                consigliere = {
                    Weapons.WEAPON_BAT,
                    Weapons.WEAPON_KNIFE,
                    Weapons.WEAPON_SWITCHBLADE,
                    Weapons.WEAPON_MACHETE,
                    Weapons.WEAPON_PISTOL,
                    Weapons.WEAPON_PISTOL_MK2,
                    Weapons.WEAPON_MINISMG,
                    Weapons.WEAPON_COMPACTRIFLE,
                    Weapons.WEAPON_ASSAULTRIFLE,
                    Weapons.WEAPON_ASSAULTRIFLE_MK2,
                    Weapons.WEAPON_SAWNOFFSHOTGUN,
                },
                don = {
                    Weapons.WEAPON_BAT,
                    Weapons.WEAPON_KNIFE,
                    Weapons.WEAPON_SWITCHBLADE,
                    Weapons.WEAPON_MACHETE,
                    Weapons.WEAPON_PISTOL,
                    Weapons.WEAPON_PISTOL_MK2,
                    Weapons.WEAPON_MINISMG,
                    Weapons.WEAPON_COMPACTRIFLE,
                    Weapons.WEAPON_ASSAULTRIFLE,
                    Weapons.WEAPON_ASSAULTRIFLE_MK2,
                    Weapons.WEAPON_SAWNOFFSHOTGUN,
                },
                boss = {
                    Weapons.WEAPON_BAT,
                    Weapons.WEAPON_KNIFE,
                    Weapons.WEAPON_SWITCHBLADE,
                    Weapons.WEAPON_MACHETE,
                    Weapons.WEAPON_PISTOL,
                    Weapons.WEAPON_PISTOL_MK2,
                    Weapons.WEAPON_MINISMG,
                    Weapons.WEAPON_COMPACTRIFLE,
                    Weapons.WEAPON_ASSAULTRIFLE,
                    Weapons.WEAPON_ASSAULTRIFLE_MK2,
                    Weapons.WEAPON_SAWNOFFSHOTGUN,
                }
            },

            AuthorizedVehicles = {
                { name = 'Kamacho',    label = '4X4' },
                { name = 'Mesa',  label = 'Jeep' },
                { name = 'Rebel',     label = 'Rebel' },
                { name = 'speedo',     label = 'Cammionette' },
            },
    
            -- Cloakrooms = {
            --     vector3(2438.745, 4963.819, 46.810), -- fait
            -- },
    
            Armories = {
                --vector3(2444.117, 4965.950, 46.810), -- fait
                vector3(1401.96, 1132.29, 113.33),
            },
    
            Vehicles = {
                {
                    --Spawner    = vector3(2451.135, 4969.503, 46.571), -- fait
                    Spawner = vector3(1413.67, 1115.8, 113.84),
                    SpawnPoint = vector3(1458.15, 1112.78,113.33), -- fait
                    Heading    = 100.66, -- fait
                }
            },

            Helicopters = {
                {
                    Spawner    = vector3(1439.65, 1109.33, 113.19),
                    SpawnPoint =  vector3(1458.15, 1112.78,113.33),
                    Heading    = 330.30,
                },
                {
                    -- sandy
                    Spawner = vector3(1384.16, 3006.80, 39.83),
                    SpawnPoint = vector3(1402.38, 3000.50, 40.55),
                    Heading = 316.0,
                }
            },
    
            VehicleDeleters = {
                --vector3(2445.463, 4953.544, 45.095), -- fait
                vector3(1458.15, 1112.78, 113.33),
                vector3(300.36,64.89,98.89),
                vector3(1398.15, 2996.79, 39.55),
                --vector3(1414.77,1119.30,113.84), -- fait
            },
    
            BossActions = {
                --vector3(2456.036, 4982.277, 46.809) -- fait
                vector3(1404.18, 1150.06, 113.33)
            }
        }
    },

    gang = {
        {
            HasJobMenu = true,
            HasPhoneNumber = false,
            HasMoneyLaundering = false,
            CanConfiscate = true,
            Blip = {
                Pos     = { x = -1559.80, y= -99.33, z = 54.98 },
                Sprite  = -1,
                Display = 4,
                Scale   = 1.2,
                Colour  = 29,
                Name = "Révoltés"
            },

            BlacklistedItems = {
                soldiers = {
                    ['black_money'] = true,
                    ['money'] = true
                }
            },

            AuthorizedWeapons = {
                soldiers = {
                    Weapons.WEAPON_BAT,
                    Weapons.WEAPON_KNIFE,
                    Weapons.WEAPON_SWITCHBLADE,
                    Weapons.WEAPON_MACHETE,
                }, -- Soldaten
                elite_three = {
                    Weapons.WEAPON_BAT,
                    Weapons.WEAPON_KNIFE,
                    Weapons.WEAPON_SWITCHBLADE,
                    Weapons.WEAPON_MACHETE,
                    Weapons.WEAPON_PISTOL,
                    Weapons.WEAPON_PISTOL_MK2,
                }, -- Elite 3
                elite_two = {
                    Weapons.WEAPON_BAT,
                    Weapons.WEAPON_KNIFE,
                    Weapons.WEAPON_SWITCHBLADE,
                    Weapons.WEAPON_MACHETE,
                    Weapons.WEAPON_PISTOL,
                    Weapons.WEAPON_PISTOL_MK2,
                    Weapons.WEAPON_SAWNOFFSHOTGUN,
                }, -- Elite 2
                elite_one = {
                    Weapons.WEAPON_BAT,
                    Weapons.WEAPON_KNIFE,
                    Weapons.WEAPON_SWITCHBLADE,
                    Weapons.WEAPON_MACHETE,
                    Weapons.WEAPON_PISTOL,
                    Weapons.WEAPON_PISTOL_MK2,
                    Weapons.WEAPON_SAWNOFFSHOTGUN,
                }, -- Elite 1
                advisor = {
                    Weapons.WEAPON_BAT,
                    Weapons.WEAPON_KNIFE,
                    Weapons.WEAPON_SWITCHBLADE,
                    Weapons.WEAPON_MACHETE,
                    Weapons.WEAPON_PISTOL,
                    Weapons.WEAPON_PISTOL_MK2,
                    Weapons.WEAPON_SAWNOFFSHOTGUN,
                    Weapons.WEAPON_MINISMG,
                    Weapons.WEAPON_COMPACTRIFLE,
                    Weapons.WEAPON_ASSAULTRIFLE,
                    Weapons.WEAPON_ASSAULTRIFLE_MK2,
                },
                chef = {
                    Weapons.WEAPON_BAT,
                    Weapons.WEAPON_KNIFE,
                    Weapons.WEAPON_SWITCHBLADE,
                    Weapons.WEAPON_MACHETE,
                    Weapons.WEAPON_PISTOL,
                    Weapons.WEAPON_PISTOL_MK2,
                    Weapons.WEAPON_MINISMG,
                    Weapons.WEAPON_COMPACTRIFLE,
                    Weapons.WEAPON_ASSAULTRIFLE,
                    Weapons.WEAPON_ASSAULTRIFLE_MK2,
                    Weapons.WEAPON_SAWNOFFSHOTGUN,
                },
                advocaat = {
                    Weapons.WEAPON_BAT,
                    Weapons.WEAPON_KNIFE,
                    Weapons.WEAPON_SWITCHBLADE,
                    Weapons.WEAPON_MACHETE,
                    Weapons.WEAPON_PISTOL,
                    Weapons.WEAPON_PISTOL_MK2,
                    Weapons.WEAPON_MINISMG,
                    Weapons.WEAPON_COMPACTRIFLE,
                    Weapons.WEAPON_ASSAULTRIFLE,
                    Weapons.WEAPON_ASSAULTRIFLE_MK2,
                    Weapons.WEAPON_SAWNOFFSHOTGUN,
                },
                boss = {
                    Weapons.WEAPON_BAT,
                    Weapons.WEAPON_KNIFE,
                    Weapons.WEAPON_SWITCHBLADE,
                    Weapons.WEAPON_MACHETE,
                    Weapons.WEAPON_PISTOL,
                    Weapons.WEAPON_PISTOL_MK2,
                    Weapons.WEAPON_MINISMG,
                    Weapons.WEAPON_COMPACTRIFLE,
                    Weapons.WEAPON_ASSAULTRIFLE,
                    Weapons.WEAPON_ASSAULTRIFLE_MK2,
                    Weapons.WEAPON_SAWNOFFSHOTGUN,
                },
            },

            AuthorizedVehicles = {},

            Armories = {
                vector3(-1562.99, -94.57, 50.09)
            },

            Vehicles = {
                {
                    --Spawner    = vector3(2451.135, 4969.503, 46.571),
                    Spawner = vector3(-1578.96, -90.23, 53.33),
                    SpawnPoint = vector3(-1571.62, -82.41, 53.33),
                    Heading    = 269.62,
                }
            },

            Helicopters = {
                {
                    Spawner    = vector3(-1579.86, -76.25, 53.13),
                    SpawnPoint = vector3(-1567.30, -82.09, 53.33),
                    Heading    = 269.62,
                },
                {
                    -- sandy
                    Spawner = vector3(1384.16, 3006.80, 39.83),
                    SpawnPoint = vector3(1402.38, 3000.50, 40.55),
                    Heading = 316 
                }
            },

            VehicleDeleters = {
                -- vector3(-1792.22, 408.99, 112.45), -- fait
                -- vector3(-1750.39, 443.48, 127.45), -- fait
                vector3(-1587.47, -82.66, 53.33),
                vector3(-1567.30, -82.09, 53.13),
                vector3(1398.15, 2996.79, 39.55),
            },

            BossActions = {
                --vector3(2456.036, 4982.277, 46.809) -- fait
                -- vector3(-1796.37, 413.38, 115.84)
                vector3(-1564.64, -96.34, 58.84)
            }
        }
    },

    narcos = {
        {
            HasJobMenu = true,
            HasPhoneNumber = false,
            HasMoneyLaundering = false,
            CanConfiscate = true,
            Blip = {
                Pos     = { x = 1376.35, y = -2076.37, z = 51.00 },
                Sprite  = -1,
                Display = 4,
                Scale   = 1.2,
                Colour  = 29,
                Name = "Narcos"
            },

            BlacklistedItems = {
            },

            AuthorizedWeapons = {
                hangaround = {},
                tirador = {},
                cazador = {},
                sicario = {},
                teniente = {},
                consejero = {},
                empresario = {
                    Weapons.WEAPON_BAT,
                    Weapons.WEAPON_KNIFE,
                    Weapons.WEAPON_SWITCHBLADE,
                    Weapons.WEAPON_MACHETE,
                    Weapons.WEAPON_PISTOL,
                    Weapons.WEAPON_PISTOL_MK2,
                },
                capitan = {
                    Weapons.WEAPON_BAT,
                    Weapons.WEAPON_KNIFE,
                    Weapons.WEAPON_SWITCHBLADE,
                    Weapons.WEAPON_MACHETE,
                    Weapons.WEAPON_PISTOL,
                    Weapons.WEAPON_PISTOL_MK2,
                    Weapons.WEAPON_MINISMG,
                    Weapons.WEAPON_COMPACTRIFLE,
                    Weapons.WEAPON_ASSAULTRIFLE,
                    Weapons.WEAPON_ASSAULTRIFLE_MK2,
                    Weapons.WEAPON_SAWNOFFSHOTGUN,
                },

                boss = { -- Baas
                    Weapons.WEAPON_BAT,
                    Weapons.WEAPON_KNIFE,
                    Weapons.WEAPON_SWITCHBLADE,
                    Weapons.WEAPON_MACHETE,
                    Weapons.WEAPON_PISTOL,
                    Weapons.WEAPON_PISTOL_MK2,
                    Weapons.WEAPON_MINISMG,
                    Weapons.WEAPON_COMPACTRIFLE,
                    Weapons.WEAPON_ASSAULTRIFLE,
                    Weapons.WEAPON_ASSAULTRIFLE_MK2,
                    Weapons.WEAPON_SAWNOFFSHOTGUN,
                }
            },

            AuthorizedVehicles = {},

            Armories = {
                vector3(1361.50, -2095.38, 46.21),
            },

            Vehicles = {
                {
                    Spawner    = vector3(1365.77, -2086.36, 51.00),
                    SpawnPoint = vector3(1356.25, -2077.98, 51.00),
                    Heading    = 304.87,
                }
            },

            Helicopters = {
                {
                    Spawner    = vector3(1384.36, -2075.75, 51.00),
                    SpawnPoint = vector3(1374.00, -2067.41, 51.00),
                    Heading    = 308.55,
                },
                {
                    -- sandy
                    Spawner = vector3(1384.16, 3006.80, 39.83),
                    SpawnPoint = vector3(1402.38, 3000.50, 40.55),
                    Heading = 316 
                }
            },

            VehicleDeleters = {
                vector3(1386.78, -2063.43, 37.38),
                vector3(1384.22, -2062.55, 51.00),
            },

            BossActions = {
                vector3(1370.75, -2090.66, 47.22)
            }
        }
    },

    reporter = {
        {
            HasJobMenu = false,
            HasPhoneNumber = true,
            HasMoneyLaundering = false,
            UseSocietyVehicles = false,
            Blip = {
                Pos     = { x = -601.82, -928.86, z = 36.83 },
                Sprite  = -1,
                Display = 4,
                Scale   = 1.2,
                Colour  = 29,
                Name = "TDA Nieuws"
            },

            AuthorizedWeapons = {
                soldato = {},
                capo = {},
                consigliere = {},
                boss = {},
                advocaat = {},
            },

            AuthorizedVehicles = {
                { name = 'rumpo',    label = 'Nieuws Busje 2p' },
                { name = 'newsvan',  label = 'Nieuws Busje 4p' },
            },

            Armories = {
                --vector3(-1150.42, -1513.50, 9.53)
            },

            Vehicles = {
                {
                    --Spawner    = vector3(2451.135, 4969.503, 46.571), -- fait
                    -- Spawner = vector3(-536.99, -887.61, 24.14),
                    -- SpawnPoint = vector3(-532.62, -891.69, 24.58), -- fait
                    -- Heading    = 179.13, -- fait

                    Spawner = vector3(-1094.79, -261.50, 36.68), --[[LifeInvader]]
                    SpawnPoint = vector3(-1099.31, -264.81, 36.68), --[[LifeInvader]]
                    Heading = 200.00 --[[LifeInvader]]
                }
            },

            Helicopters = {
                {
                    AllowAllGrades = true,
                    -- Spawner    = vector3(-570.00, -922.91, 35.83),
                    -- SpawnPoint = vector3(-582.82, -930.53, 35.83),
                    -- Heading    = 210.0,
                    Spawner = vector3(-1062.42, -243.79, 53.01), --[[LifeInvader]]
                    SpawnPoint = vector3(-1049.31, -234.87, 52.51), --[[LifeInvader]]
                    Heading = 118.51, --[[LifeInvader]]
                    Model = 'newsfrog'
                }
            },

            VehicleDeleters = {
                --vector3(2445.463, 4953.544, 45.095), -- fait
                -- vector3(-525.02, -884.17, 24.13), -- fait
                vector3(-1054.56, -242.83, 36.69), -- LifeInvader
            },


            BossActions = {
                --vector3(2456.036, 4982.277, 46.809) -- fait
                vector3(-583.86, -935.16, 27.16)
            }
        }
    },
    
    reporter2 = {
        {
            HasJobMenu = false,
            HasPhoneNumber = true,
            HasMoneyLaundering = false,
            UseSocietyVehicles = false,
            Blip = {
                Pos     = { x = -601.82, -928.86, z = 36.83 },
                Sprite  = -1,
                Display = 4,
                Scale   = 1.2,
                Colour  = 29,
                Name = "TDA-AD"
            },

            AuthorizedWeapons = {
                soldato = {},
                capo = {},
                consigliere = {},
                boss = {},
                advocaat = {},
            },

            AuthorizedVehicles = {
                -- { name = 'rumpo',    label = 'Nieuws Busje 2p' },
                -- { name = 'newsvan',  label = 'Nieuws Busje 4p' },
            },

            Armories = {
                --vector3(-1150.42, -1513.50, 9.53)
            },

            Vehicles = {
                {
                    --Spawner    = vector3(2451.135, 4969.503, 46.571), -- fait
                    -- Spawner = vector3(-536.99, -887.61, 24.14),
                    -- SpawnPoint = vector3(-532.62, -891.69, 24.58), -- fait
                    -- Heading    = 179.13, -- fait
                }
            },

            Helicopters = {
                -- {
                --     AllowAllGrades = true,
                --     Spawner    = vector3(-570.00, -922.91, 35.83),
                --     SpawnPoint = vector3(-582.82, -930.53, 35.83),
                --     Heading    = 210.0,
                --     Model = 'newsfrog'
                -- }
            },

            VehicleDeleters = {
                --vector3(2445.463, 4953.544, 45.095), -- fait
                -- vector3(-525.02, -884.17, 24.13), -- fait
            },

            BossActions = {
                --vector3(2456.036, 4982.277, 46.809) -- fait
                vector3(-583.86, -935.16, 27.16)
            }
        }
    },

    media = {
        {
            HasJobMenu = false,
            HasPhoneNumber = true,
            HasMoneyLaundering = false,
            UseSocietyVehicles = false,
            Blip = {
                Pos     = { x = -583.53, y= -924.78, z = 36.83 },
                Sprite  = 590,
                Display = 4,
                Scale   = 1.2,
                Colour  = 29,
                Name = "TDA Media"
            },

            AuthorizedWeapons = {
                soldato = {},
                capo = {},
                consigliere = {},
                boss = {},
                advocaat = {},
            },

            AuthorizedVehicles = {
                { name = 'rumpo',    label = 'Nieuws Busje 2p' },
                { name = 'newsvan',  label = 'Nieuws Busje 4p' },
            },

            Armories = {
                --vector3(-1150.42, -1513.50, 9.53)
            },

            Vehicles = {
                {
                    Spawner = vector3(-1094.79, -261.50, 36.68), --[[LifeInvader]]
                    SpawnPoint = vector3(-1099.31, -264.81, 36.68), --[[LifeInvader]]
                    Heading = 200.00 --[[LifeInvader]]
                },
                {
                    Spawner = vector3(-536.99, -887.61, 24.14),
                    SpawnPoint = vector3(-532.62, -891.69, 24.58), -- fait
                    Heading    = 179.13, -- fait
                }
            },

            Helicopters = {
                {
                    AllowAllGrades = true,
                    Spawner = vector3(-1062.42, -243.79, 53.01), --[[LifeInvader]]
                    SpawnPoint = vector3(-1049.31, -234.87, 52.51), --[[LifeInvader]]
                    Heading = 118.51, --[[LifeInvader]]
                    Model = 'newsfrog'
                },
                {
                    AllowAllGrades = true,
                    Spawner    = vector3(-570.00, -922.91, 35.83),
                    SpawnPoint = vector3(-582.82, -930.53, 35.83),
                    Heading    = 210.0,
                    Model = 'newsfrog'
                }
            },

            VehicleDeleters = {
                --vector3(2445.463, 4953.544, 45.095), -- fait
                vector3(-525.02, -884.17, 24.13),
                vector3(-1054.56, -242.83, 36.69), -- LifeInvader
                vector3(-583.5, -930.32, 35.83)
            },


            BossActions = {
                --vector3(2456.036, 4982.277, 46.809) -- fait
                vector3(-583.86, -935.16, 27.16)
            }
        }
    },

    peaky = {
        [1] = {
            HasJobMenu = true,
            HasPhoneNumber = false,
            HasMoneyLaundering = true,
            CanConfiscate = true,
            Blip = {
                Pos     = { x = -82.73, y = 1000.30, z = 234.43 },
                Sprite  = 378,
                Display = 4,
                Scale   = 1.4,
                Colour  = 38
            },
    
            AuthorizedWeapons = {
                guard = {
                },
                communicators = {
                },
                chief = {
                },
                bookkeeper = {},
                cochairman = {
                    Weapons.WEAPON_BAT,
                    Weapons.WEAPON_KNIFE,
                    Weapons.WEAPON_SWITCHBLADE,
                    Weapons.WEAPON_MACHETE,
                    Weapons.WEAPON_PISTOL,
                    Weapons.WEAPON_PISTOL_MK2,
                    Weapons.WEAPON_MINISMG,
                    Weapons.WEAPON_COMPACTRIFLE,
                    Weapons.WEAPON_ASSAULTRIFLE,
                    Weapons.WEAPON_ASSAULTRIFLE_MK2,
                    Weapons.WEAPON_SAWNOFFSHOTGUN,
                },
                boss = {
                    Weapons.WEAPON_BAT,
                    Weapons.WEAPON_KNIFE,
                    Weapons.WEAPON_SWITCHBLADE,
                    Weapons.WEAPON_MACHETE,
                    Weapons.WEAPON_PISTOL,
                    Weapons.WEAPON_PISTOL_MK2,
                    Weapons.WEAPON_MINISMG,
                    Weapons.WEAPON_COMPACTRIFLE,
                    Weapons.WEAPON_ASSAULTRIFLE,
                    Weapons.WEAPON_ASSAULTRIFLE_MK2,
                    Weapons.WEAPON_SAWNOFFSHOTGUN,
                }
            },
    
            AuthorizedVehicles = {
                { name = 'gburrito2',  label = 'Busje', price = 1000 },
                { name = 'avarus',    label = 'Motor Avarus', price = 10000 },
                { name = 'sanctus',   label = 'Motor Sanctus', price = 10000 },
                { name = '4x4',      label = '4x4', price = 100000 },
                { name = 'rrphantom',      label = 'Patrov baas', price = 5000000},
            },
    
            Armories = {
                vector3(-112.07, 991.43, 239.84),
            },
    
            Vehicles = {
                {
                    Spawner    = vector3(-128.01, 1008.98, 234.73),
                    SpawnPoint = vector3(-125.51, 997.35, 239.92),
                    Heading    = 101.56,
                }
            },
    
            Helicopters = {
                {
                    Spawner    = vector3( -111.26, 977.61, 234.76),
                    SpawnPoint = vector3(-119.06,972.53, 239.07),
                    Heading    = 59.83,
                },
                {
                    -- sandy
                    Spawner = vector3(1384.16, 3006.80, 39.83),
                    SpawnPoint = vector3(1402.38, 3000.50, 40.55),
                    Heading = 316 
                }
            },
    
            VehicleDeleters = {
               vector3( -125.51, 997.35, 238.92),
               vector3(-130.22, 1003.97, 234.73),
               vector3(1398.15, 2996.79, 39.55),
            },
    
            BossActions = {
                vector3(-104.94, 978.35, 239.88)
            },
        }
    },
    justitie = {
        {
            HasJobMenu = true,
            HasPhoneNumber = true,
            HasMoneyLaundering = false,
            UseSocietyVehicles = false,
            Blip = {
                Pos     = { x = -536.00, y= -185.50, z = 38.22 },
                Sprite  = 498,
                Display = 4,
                Scale   = 1.2,
                Colour  = 29,
                Name    = "Ministerie van Justitie en Veiligheid"
            },

            AuthorizedWeapons = {
            },

            AuthorizedVehicles = {
                { name = 'mvolvo',    label = 'Volvo' },
            },

            Armories = {
            },

            Vehicles = {
                {
                    Spawner = vector3(-587.39, -224.86, 35.57), --[[LifeInvader]]
                    SpawnPoint = vector3(-590.73, -227.61, 36.44), --[[LifeInvader]]
                    Heading = 207.00 --[[LifeInvader]]
                },
            },

            Helicopters = {
            },

            VehicleDeleters = {
                vector3(-580.38, -247.16, 34.47),
            },

            BossActions = {
                vector3(-584.91, -202.95, 41.84),
                vector3(-533.23, -172.64, 41.84),
            }
        }
    },

    lcardealer = {
        {
            HasJobMenu = false,
            HasPhoneNumber = false,
            HasMoneyLaundering = false,
            Blip = {
                Pos     = { x = 110.90, y= -152.30, z = 53.87 },
                Sprite  = 225,
                Display = 4,
                Scale   = 1.2,
                Colour  = 29,
            },

            AuthorizedWeapons = {
            },

            AuthorizedVehicles = {
            },

            Armories = {
            },

            Vehicles = {
                {
                    Spawner    = vector3(126.53,-126.20, 53.83),
                    SpawnPoint = vector3(124.15, -120.38, 53.84),
                    Heading    = 157.16,
                }
            },

            Helicopters = {
            },

            VehicleDeleters = {
                vector3( 145.31, -127.64, 53.83),
             },

            BossActions = {
                vector3(148.21, -141.80, 53.80)
            }
        }
    },

    bratva = {
        [1] = {
            HasJobMenu = true,
            HasPhoneNumber = false,
            HasMoneyLaundering = true,
            CanConfiscate = true,
            Blip = {
                Pos     = {x= -1518.15, y= 837.77, z= 185.20 },
                Sprite  = 378,
                Display = 4,
                Scale   = 1.4,
                Colour  = 38
            },

            AuthorizedWeapons = {
                soldato = {
                    Weapons.WEAPON_BAT,
                    Weapons.WEAPON_KNIFE,
                    Weapons.WEAPON_SWITCHBLADE,
                },
                capo = {
                    Weapons.WEAPON_BAT,
                    Weapons.WEAPON_KNIFE,
                    Weapons.WEAPON_SWITCHBLADE,
                    Weapons.WEAPON_MACHETE,
                },
                advocaat = {
                    Weapons.WEAPON_BAT,
                    Weapons.WEAPON_KNIFE,
                    Weapons.WEAPON_SWITCHBLADE,
                    Weapons.WEAPON_MACHETE,
                    Weapons.WEAPON_PISTOL,
                    Weapons.WEAPON_PISTOL_MK2,
                    Weapons.WEAPON_MINISMG,
                    Weapons.WEAPON_COMPACTRIFLE,
                    Weapons.WEAPON_ASSAULTRIFLE,
                    Weapons.WEAPON_ASSAULTRIFLE_MK2,
                    Weapons.WEAPON_SAWNOFFSHOTGUN,
                },
                consigliere = {
                    Weapons.WEAPON_BAT,
                    Weapons.WEAPON_KNIFE,
                    Weapons.WEAPON_SWITCHBLADE,
                    Weapons.WEAPON_MACHETE,
                    Weapons.WEAPON_PISTOL,
                    Weapons.WEAPON_PISTOL_MK2,
                    Weapons.WEAPON_MINISMG,
                    Weapons.WEAPON_COMPACTRIFLE,
                    Weapons.WEAPON_ASSAULTRIFLE,
                    Weapons.WEAPON_ASSAULTRIFLE_MK2,
                    Weapons.WEAPON_SAWNOFFSHOTGUN,
                },
                boss = {
                    Weapons.WEAPON_BAT,
                    Weapons.WEAPON_KNIFE,
                    Weapons.WEAPON_SWITCHBLADE,
                    Weapons.WEAPON_MACHETE,
                    Weapons.WEAPON_PISTOL,
                    Weapons.WEAPON_PISTOL_MK2,
                    Weapons.WEAPON_MINISMG,
                    Weapons.WEAPON_COMPACTRIFLE,
                    Weapons.WEAPON_ASSAULTRIFLE,
                    Weapons.WEAPON_ASSAULTRIFLE_MK2,
                    Weapons.WEAPON_SAWNOFFSHOTGUN,
                },
                
            },

            AuthorizedVehicles = {
                { name = 'gburrito2',  label = 'Busje', price = 1000 },
                { name = 'avarus',    label = 'Motor Avarus', price = 10000 },
                { name = 'sanctus',   label = 'Motor Sanctus', price = 10000 },
                { name = '4x4',      label = '4x4', price = 100000 },
                { name = 'rrphantom',      label = 'Patrov baas', price = 5000000},
            },

            Armories = {
                vector3(-1511.82, 840.32, 176.00)
            },

            Vehicles = {
                {
                    SpawnPoint =  vector3(-1543.48, 885.50, 182.08),
                    Spawner = vector3(-1531.39, 877.79, 180.62),
                    Heading = 296.25
                }
            },

            Helicopters = {
                {
                    Spawner = vector3(-1541.98, 864.37, 180.49),
                    SpawnPoint = vector3(-1563.10, 847.09, 183.51),
                    Heading = 302.23 
                },
                {
                    -- sandy
                    Spawner = vector3(1384.16, 3006.80, 39.83),
                    SpawnPoint = vector3(1402.38, 3000.50, 40.55),
                    Heading = 316 
                }
            },

            VehicleDeleters = {
                vector3(-1550.68, 879.84, 180.32),
                vector3(-1562.88, 847.27, 182.57),
                vector3(1398.15, 2996.79, 39.55),
            },

            BossActions = {
                vector3(-1511.94, 839.03, 185.20)
            },
        }
    },
}
